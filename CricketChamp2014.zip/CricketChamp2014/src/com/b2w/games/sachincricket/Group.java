package com.b2w.games.sachincricket;

import javax.microedition.khronos.opengles.GL10;

import com.b2w.games.sachincricket.view.AdsListner;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Handler;
import android.view.MotionEvent;

public class Group extends Mesh {
	public Start mStart;
	int setbat = 0;
	int cntr = 0;
	int counterdeth = 0;
	float hospitalx = 1f;
	boolean vari = true;
	boolean forblood1 = false;
	boolean forblood2 = false;
	boolean forblood3 = false;
	boolean forblood4 = false;

	boolean variX = true;
	boolean select = false;
	boolean select2 = false;
	boolean select1 = false;
	int pd = 0;
	boolean shot = false;
	boolean setShot = false;
	boolean setBlood = false;
	boolean setBlood1 = false;
	boolean deth = false;
	boolean forLine1 = false;
	boolean forLine2 = false;
	float xlineLine;
	float ylineLine;
	float mx = -0.29f;
	float my = 0.62f;
	float mx1 = -0.39f;
	float my1 = -0.75f;
	int abc = 0;
	int abc1 = 0;
	int hospital = 0;
	boolean hospitalVar = false;
	int counter = 0;
	int counter1 = 0;

	int blood1 = 0;
	boolean bloodb = false;
	int a = 0;
	Handler handler;
	float ballx = -0.14f;
	float bally = -0.058f;

	GameRender mGr = null;
	int i, cnt, cnt1, gameBg;
	float ScalX, ScalY;
	float Scalvalue = 1.15f;
	float Scalvalue1 = 1.15f;

	boolean setShots = false, setStumps = false, ballHit = false,
			Balldown = false, Flag = false;
	boolean boundary6 = false, boundary4 = false, boundary3 = false,
			boundary2 = false, boundary1 = false, out = false;

	Thread t = new Thread();
	private AdsListner listner;

	// SimplePlane[]
	// image={mGr.mImg_bowlerSide0,mGr.mImg_bowlerSide1,mGr.mImg_bowlerSide2,mGr.mImg_bowlerSide3,mGr.mImg_bowlerSide4,mGr.mImg_bowlerSide5,mGr.mImg_bowlerSide6,mGr.mImg_bowlerSide7,mGr.mImg_bowlerSide8};
	//
	public Group(GameRender _GamesStarted) {
		mGr = _GamesStarted;
	}

	public void Draw(GL10 g) {
		switch (M.GameScreen) {
		case M.GameLogo:
			mGr.mTex_Logo.draw(g);
			if (cnt > 175) {
				M.GameScreen = M.GameSplash;
				cnt = 0;
			}
			cnt++;
			break;
		case M.GameSplash:
			DrawSplash(g);
			break;
		// case M.GameSubSplash:
		// DrawSplash(g);
		// break;
		case M.GameMenu:
			DrawMenu(g);
			break;
		case M.GamePause:
		case M.GamePlay:
			//Manoj Game Ends Here Activate it
			DrawGamePlay(g);
			break;
		case M.GameOver:
		case M.PlayAgain:
			DrawGameOver(g);
			DrawPlayAgain(g);
			break;

		case M.GameWinMidium:
			DrawWinMidium(g);
			break;
		case M.GameWinHard:
			DrawWinHard(g);
			break;
		}
	}

	void DrawSplash(GL10 gl) {

		if (ScalX > 1.4f)
			ScalY = -.05f;
		if (ScalX < 0.9f)
			ScalY = 0.05f;
		ScalX += ScalY;
		mGr.mTex_Splash.draw(gl);
		mGr.mImg_play.drawPos(gl, 0.797f, -0.89f);
	}

	void DrawWinMidium(GL10 gl) {
		mGr.mImg_HospitalBg.draw(gl);
		mGr.mImg_winmedium.draw(gl);
		mGr.mImg_play.drawPos(gl, 0.738f, -0.518f);
		// mStart.callAdds();
		// if(mStart.adView!=null) {
		// if(mGr.resumeCounter<150) {
		// int inv=mStart.adView.getVisibility();
		// if(inv==AdView.INVISIBLE){
		// try{handler.sendEmptyMessage(AdView.VISIBLE);
		// }catch(Exception e) {}
		// }
		// }else {
		// int inv=mStart.adView.getVisibility();
		// if(inv==AdView.VISIBLE){
		// try{handler.sendEmptyMessage(AdView.INVISIBLE);
		// }catch(Exception e){}
		// }
		// }
		// }
		// mGr.resumeCounter++;
	}

	void DrawWinHard(GL10 gl) {
		mGr.mImg_HospitalBg.draw(gl);
		mGr.mImg_winhard.draw(gl);
		mGr.mImg_play.drawPos(gl, 0.738f, -0.518f);
		// mStart.callAdds();
		// if(mStart.adView!=null) {
		// if(mGr.resumeCounter<150) {
		// int inv=mStart.adView.getVisibility();
		// if(inv==AdView.INVISIBLE){
		// try{handler.sendEmptyMessage(AdView.VISIBLE);
		// }catch(Exception e) {}
		// }
		// }else {
		// int inv=mStart.adView.getVisibility();
		// if(inv==AdView.VISIBLE){
		// try{handler.sendEmptyMessage(AdView.INVISIBLE);
		// }catch(Exception e){}
		// }
		// }
		// }
		// mGr.resumeCounter++;
	}

	void DrawMenu(GL10 gl) {

		mGr.mImg_HospitalBg.draw(gl);
		mGr.mImg_board.drawPos(gl, 0.0f, +0.05f);
		mGr.mTex_choosematch.drawPos(gl, 0.0f, 0.38f);
		mGr.mImg_easy.drawPos(gl, 0.0f, 0.22f);
		mGr.mImg_medium.drawPos(gl, 0.0f, -0.001f);
		mGr.mImg_hard.drawPos(gl, 0.0f, -0.22f);
		switch (mGr.mMenusel) {
		case 1:
			mGr.mImg_easy1.drawScal1(gl, Scalvalue, 0.0f, 0.22f);
			break;
		case 2:
			mGr.mImg_medium1.drawScal1(gl, Scalvalue, +0.0f, -0.001f);
			break;
		case 3:
			mGr.mImg_hard1.drawScal1(gl, Scalvalue, 0f, -0.22f);
			break;
		}

	}

	void DrawPlayAgain(GL10 gl) {
		mGr.mImg_Bg.draw(gl);
		mGr.mImg_gameover.drawPos(gl, 0.0f, 0.0f);
		mGr.mImg_playAgain.drawPos(gl, 0.0f, -0.2f);

	}

	void DrawGameOver(GL10 gl) {

		float yDis = -0.1f;
		mGr.mImg_Bg.draw(gl);
		mGr.mImg_board.drawPos(gl, 0.0f, +0.05f);

		switch (mGr.mLevel) {
		case 1:
			if (mGr.mScore >= 0 && mGr.mScore < mGr.mHighScoreWicket1) {
				mGr.mTex_oops.drawPos(gl, 0.0f, 0.45f);
				mGr.mTex_tryagain.drawPos(gl, 0.0f, +0.15f + yDis);
				mGr.mTex_bestscore.drawPos(gl, -0.1f, 0.0f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.0f, +0.22f);
				mGr.drawNumber(gl, mGr.mLevel, 0.075f, -0.001f + yDis);
				mGr.drawNumber(gl, mGr.mHighScoreWicket1, 0.45f, -0.005f + yDis);
			} else if (mGr.mScore > 0 && mGr.mHighScoreWicket1 == 0) {
				mGr.mTex_newScore.drawPos(gl, 0.0f, 0.55f + yDis);
				mGr.mTex_highestscore.drawPos(gl, 0.0f, +0.15f + yDis);
				mGr.mTex_whenbatting.drawPos(gl, 0.0f, 0.0f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.0f, +0.22f);
				mGr.drawNumber(gl, mGr.mLevel, 0.18f, +0.005f + yDis);
			} else if (mGr.mScore >= mGr.mHighScoreWicket1) {
				mGr.mTex_congratulation.drawPos(gl, 0.0f, 0.55f + yDis);
				mGr.mTex_bestscore.drawPos(gl, -0.1f, +0.015f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.0f, +0.14f);
				mGr.drawNumber(gl, mGr.mLevel, 0.075f, 0.007f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.45f, 0.01f + yDis);
			}
			break;
		case 2:
			if (mGr.mScore >= 0 && mGr.mScore < mGr.mHighScoreWicket5) {
				mGr.mTex_oops.drawPos(gl, 0.0f, 0.45f);
				mGr.mTex_tryagain.drawPos(gl, 0.0f, +0.15f + yDis);
				mGr.mTex_bestscore.drawPos(gl, -0.1f, 0.0f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.0f, +0.22f);
				mGr.drawNumber(gl, mGr.mLevel, 0.075f, -0.001f + yDis);
				mGr.drawNumber(gl, mGr.mHighScoreWicket5, 0.45f, -0.005f + yDis);
			} else if (mGr.mScore > 0 && mGr.mHighScoreWicket5 == 0) {
				mGr.mTex_newScore.drawPos(gl, 0.0f, 0.55f + yDis);
				mGr.mTex_highestscore.drawPos(gl, 0.0f, +0.15f + yDis);
				mGr.mTex_whenbatting.drawPos(gl, 0.0f, 0.0f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.0f, +0.22f);
				mGr.drawNumber(gl, mGr.mLevel, 0.18f, +0.005f + yDis);
			} else if (mGr.mScore >= mGr.mHighScoreWicket5) {
				mGr.mTex_congratulation.drawPos(gl, 0.0f, 0.55f + yDis);
				mGr.mTex_bestscore.drawPos(gl, -0.1f, +0.015f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.0f, +0.14f);
				mGr.drawNumber(gl, mGr.mLevel, 0.075f, 0.007f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.45f, 0.01f + yDis);
			}
			break;
		case 3:
			if (mGr.mScore >= 0 && mGr.mScore < mGr.mHighScoreWicket11) {
				mGr.mTex_oops.drawPos(gl, 0.0f, 0.45f);
				mGr.mTex_tryagain.drawPos(gl, 0.0f, +0.15f + yDis);
				mGr.mTex_bestscore.drawPos(gl, -0.1f, 0.0f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.0f, +0.22f);
				mGr.drawNumber(gl, mGr.mLevel, 0.065f, -0.001f + yDis);
				mGr.drawNumber(gl, mGr.mHighScoreWicket11, 0.45f, -0.005f
						+ yDis);
			} else if (mGr.mScore > 0 && mGr.mHighScoreWicket11 == 0) {
				mGr.mTex_newScore.drawPos(gl, 0.0f, 0.55f + yDis);
				mGr.mTex_highestscore.drawPos(gl, 0.0f, +0.15f + yDis);
				mGr.mTex_whenbatting.drawPos(gl, 0.0f, 0.0f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.0f, +0.22f);
				mGr.drawNumber(gl, mGr.mLevel, 0.174f, +0.005f + yDis);
			} else if (mGr.mScore >= mGr.mHighScoreWicket11) {
				mGr.mTex_congratulation.drawPos(gl, 0.0f, 0.55f + yDis);
				mGr.mTex_bestscore.drawPos(gl, -0.1f, +0.015f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.0f, +0.14f);
				mGr.drawNumber(gl, mGr.mLevel, 0.065f, 0.007f + yDis);
				mGr.drawNumber(gl, mGr.mScore, 0.45f, 0.01f + yDis);
			}
			break;
		}
		mGr.mTex_playagain.drawPos(gl, -0.37f, -0.3f + yDis);
		mGr.mTex_exit.drawPos(gl, 0.37f, -0.3f + yDis);
		switch (mGr.mMenusel) {
		case 1:
			mGr.mTex_playagain.drawScal1(gl, Scalvalue, -0.37f, -0.3f + yDis);
			break;
		case 2:
			mGr.mTex_exit.drawScal1(gl, Scalvalue, +0.37f, -0.3f + yDis);
			break;
		}
		if(listner!=null)
		listner.showAds();
	}

	// start Game Play drawing..........????????

	void DrawGamePlay(GL10 gl) {
		if (hospitalVar) {
			DrawHospital(gl);
			hospital++;
		} else {
			cnt1++;
			mGr.mImg_Bg.draw(gl);

			mGr.mImg_selectIcon.drawScal1(gl, Scalvalue, 0.79f, -0.9f);
			if (mGr.setKeeper == true) {
				DrawKeeper(gl);
			} else {
				mGr.mImg_keeper[0].drawPos(gl, -0.001f, 0.32f);
			}
			if (mGr.setBatssman == true) {
				setShot = true;
				a = 0;
				if (mGr.xline > -0.17f && mGr.xline <= -0.05f
						&& mGr.yline > 0.37f && mGr.yline <= 42f) {
					if (mGr.countX11 < 6) {
						mGr.betsman++;
						if (mGr.betsman > 5) {
							mGr.countX11++;
							mGr.betsman = 0;
						}
					}
					mGr.mImg_player22[mGr.countX11].drawPos(gl, 0.01f, 0.32f);
					a = 1;
				} else if (mGr.xline >= -0.03f && mGr.xline <= 0.04f
						&& mGr.yline <= 0.29f) {
					if (mGr.countX11 < 6) {
						mGr.betsman++;
						if (mGr.betsman > 5) {
							mGr.countX11++;
							mGr.betsman = 0;
						}
					}
					mGr.mImg_player3[mGr.countX11].drawPos(gl, 0.1f, 0.35f);
					a = 2;
				} else if (mGr.xline > -0.08f && mGr.xline <= -0.009f
						&& mGr.yline < 0.32f) {
					if (mGr.countX11 < 6) {
						mGr.betsman++;
						if (mGr.betsman > 5) {
							mGr.countX11++;
							mGr.betsman = 0;
						}
					}
					mGr.mImg_player4[mGr.countX11].drawPos(gl, 0.1f, 0.32f);
					a = 3;
				} else if (mGr.xline > -0.07f && mGr.xline <= 0.05f
						&& mGr.yline < 0.35f && mGr.yline > 0.32f) {
					if (mGr.countX11 < 5) {
						mGr.betsman++;
						if (mGr.betsman > 6) {
							mGr.countX11++;
							mGr.betsman = 0;
						}
					}
					mGr.mImg_player6[mGr.countX11].drawPos(gl, 0.09f, 0.32f);
					a = 4;
				} else if (mGr.xline >= 0.09f && mGr.xline <= 0.25f
						&& mGr.yline >= 0.4f && mGr.yline <= 0.43f) {
					if (mGr.countX11 < 6) {
						mGr.betsman++;
						if (mGr.betsman > 5) {
							mGr.countX11++;
							mGr.betsman = 0;
						}
					}
					mGr.mImg_player7[mGr.countX11].drawPos(gl, 0.09f, 0.32f);
					a = 5;
				} else if (mGr.xline > 0.002f && mGr.xline <= 0.17f
						&& mGr.yline <= 0.29f) {
					if (mGr.countX11 < 5) {
						mGr.betsman++;
						if (mGr.betsman > 6) {
							mGr.countX11++;
							mGr.betsman = 0;
						}
					}
					mGr.mImg_player8[mGr.countX11].drawPos(gl, 0.09f, 0.35f);
					a = 6;
				} else if (mGr.xline >= 0.14f && mGr.xline <= 0.20f
						&& mGr.yline <= 0.35f && mGr.yline >= 0.30f) {
					if (mGr.blood < 3) {

						mGr.mImg_player1[mGr.countX1 / 18 % 2].drawPos(gl,
								0.1f, 0.29f);
						// Drawblood1(gl);
					}
					// forblood1=true;
					counter++;
					a = 7;
				} else if (mGr.xline > 0.07f && mGr.xline < 0.12f
						&& mGr.yline > 0.33f && mGr.yline < 0.395f) {
					if (mGr.blood < 3) {
						mGr.mImg_player1[mGr.countX1 / 18 % 2].drawPos(gl,
								0.1f, 0.29f);
						// Drawblood1(gl);
					}
					// forblood2=true;
					// Drawblood1(gl);
					a = 8;
				} else if (mGr.xline > 0.09f && mGr.xline < 0.16f
						&& mGr.yline > 0.28f && mGr.yline < 0.36f) {
					if (mGr.blood < 3) {
						mGr.mImg_player1[mGr.countX1 / 18 % 2].drawPos(gl,
								0.1f, 0.29f);
						// Drawblood1(gl);
					}
					// forblood3=true;
					// Drawblood1(gl);
					a = 9;
				} else if (mGr.xline > 0.04f && mGr.xline < 0.08
						&& mGr.yline == .39f) {
					if (mGr.blood < 3) {
						mGr.mImg_player1[mGr.countX1 / 18 % 2].drawPos(gl,
								0.1f, 0.29f);
						// Drawblood1(gl);
					}
					// forblood4=true;
					// Drawblood1(gl);
					a = 10;
				} else if (mGr.xline < -0.01f) {
					if (mGr.countX11 / 12 % 7 < 7) {
						mGr.mImg_player4[mGr.countX11 / 12 % 7].drawPos(gl,
								0.1f, 0.32f);
					} else {
						mGr.mImg_player1[mGr.countX1 / 18 % 2].drawPos(gl,
								0.1f, 0.29f);
					}
					a = 11;
					// mGr.mImg_player1[mGr.countX1/18%2].drawPos(gl, 0.1f,
					// 0.29f);
				} else if (mGr.xline > -0.01f) {
					if (mGr.countX11 / 10 % 6 < 7) {
						mGr.mImg_player8[mGr.countX11 / 10 % 6].drawPos(gl,
								0.09f, 0.35f);
					} else {
						mGr.mImg_player1[mGr.countX1 / 18 % 2].drawPos(gl,
								0.1f, 0.29f);
					}
					a = 12;
					// mGr.mImg_player1[mGr.countX1/18%2].drawPos(gl, 0.1f,
					// 0.29f);
				}
				mGr.abcd++;
				Drawblood1(gl);
			} else {
				counter1++;
				if (mGr.blood != 3) {
					mGr.mImg_player1[mGr.countX1 / 18 % 2].drawPos(gl, 0.1f,
							0.29f);
				}
				Drawblood1(gl);
			}
			if (M.GameScreen != M.GamePause) {
				mGr.countX1++;
				mGr.countX2++;
				if (mGr.mLevel == 3 && select2 == false) {
					a = 0;
					selectionLogic();
					selectionLogic1();
					mGr.mImg_selection.drawPos(gl, 0.04f, 0.30f);
					mGr.mImg_Xline.drawPos(gl, 0.04f, mGr.yline);
					mGr.mImg_Yline.drawPos(gl, mGr.xline, 0.3f);

				} else if (select2 == true) {
					DrawBoller(gl);
					abc++;
					DrawBoller1(gl);
					abc1++;
					if (abc1 > 23) {
						mGr.mImg_bowler[21].drawPos(gl, -0.5f, -0.19f);
					}
					if (abc1 > 14) {
						ballingLogic(gl);
						if (M.setValue11 == true) {
							mGr.mImg_ball.drawPos(gl, ballx, bally);
						}
					}
				}
				if (mGr.mLevel == 1 || mGr.mLevel == 2) {
					if (select == false) {
						a = 0;
						mGr.mImg_selection.drawPos(gl, 0.04f, 0.30f);
						mGr.mImg_Yline.drawPos(gl, mGr.xline, 0.3f);
						selectionLogic();
					} else if (select1 == true) {
						selectionLogic1();
						mGr.mImg_selection.drawPos(gl, 0.04f, 0.30f);
						mGr.mImg_Xline.drawPos(gl, 0.04f, mGr.yline);
						mGr.mImg_Yline.drawPos(gl, mGr.xline, 0.3f);
					} else {
						DrawBoller(gl);
						abc++;
						DrawBoller1(gl);
						abc1++;
						if (abc1 > 23) {
							mGr.mImg_bowler[21].drawPos(gl, -0.5f, -0.19f);
						}
						if (abc1 > 14) {
							ballingLogic(gl);
							if (M.setValue11 == true) {
								mGr.mImg_ball.drawPos(gl, ballx, bally);
							}
						}
					}
				}
				if (mGr.countX1 % 3 == 0) {
					mGr.countP1++;
				}
				if (mGr.countX2 % 10 == 0) {
					mGr.countW1++;
				}
			}
			mGr.mImg_top.draw(gl);
			mGr.mImg_sideplayer.drawScal1(gl, Scalvalue, -0.67f, 0.38f);
			mGr.mImg_sideplayer.drawScal1(gl, Scalvalue, 0.68f, 0.38f);
			DrawScore(gl);
			mGr.mImg_soundOn.drawScal1(gl, Scalvalue, 0.79f, 0.6f);
			if (M.setValue == false) {
				mGr.mImg_soundOff.drawScal1(gl, Scalvalue, 0.79f, 0.6f);
				M.stop(mGr.mContext);
			}
			if (M.setValue == true) {
				M.BloodSound(mGr.mContext, R.drawable.introloop_0001);
			}
			mGr.mImage_pause.drawPos(gl, -0.79f, -0.9f);
			if (M.setValue11 == false) {
				mGr.mImage_play.drawPos(gl, -0.79f, -0.9f);
			}
			mGr.sm++;
			if (mGr.sm > 17) {
				mGr.speedup++;
				mGr.maxpower++;
			}
			if (mGr.maxpower > 6) {
				mGr.maxpower = 0;
			}
			if (mGr.speedup > 6) {
				mGr.speedup = 0;
			}
			if (mGr.overA == 5 && mGr.avari < 14) {
				if (mGr.player > 5) {
					mGr.avari++;
					mGr.mImage_Speedup[mGr.speedup].drawPos(gl, 0f, 0.35f);
				} else {
					mGr.avari++;
					mGr.mImage_maxPower[mGr.maxpower].drawPos(gl, 0f, 0.35f);
				}
			}
			if (M.GameScreen != M.GamePause) {
				// mGr.countP1=0;
				// setShots=false;
				//
				// if (select==false) {
				// mGr.mImg_selection.drawPos(gl,0.04f, 0.30f);
				// mGr.mImg_Yline.drawPos(gl, mGr.xline, 0.3f);
				// }else if (select1==true) {
				// mGr.mImg_selection.drawPos(gl,0.04f, 0.30f);
				// mGr.mImg_Xline.drawPos(gl, 0.04f, mGr.yline);
				// mGr.mImg_Yline.drawPos(gl, mGr.xline, 0.3f);
				// }
				if (abc < 9) {
					mGr.mImg_player2[0].drawPos(gl, 0.5f, -0.39f);
				} else {
					mGr.mImg_player2[1].drawPos(gl, 0.5f, -0.39f);
				}
				mGr.mImg_umpire.drawScal1(gl, Scalvalue, 0.09f, -0.60f);
				// // mGr.mImg_selection.drawPos(gl,0.04f, 0.30f);
			} else {
				mGr.mImg_selection.drawPos(gl, 0.04f, 0.30f);
				mGr.mImg_umpire.drawScal1(gl, Scalvalue, 0.09f, -0.60f);
				if (select == false) {
					mGr.mImg_Yline.drawPos(gl, mGr.xline, 0.3f);
				} else if (select1 == true) {
					mGr.mImg_Xline.drawPos(gl, 0.04f, mGr.yline);
					mGr.mImg_Yline.drawPos(gl, mGr.xline, 0.3f);
				}
				if (abc < 9) {
					mGr.mImg_player2[0].drawPos(gl, 0.5f, -0.39f);
				} else {
					mGr.mImg_player2[1].drawPos(gl, 0.5f, -0.39f);
				}
				if (M.setValue11 == true) {
					mGr.mImg_ball.drawPos(gl, ballx, bally);
				}

				// mGr.mImg_selection.drawPos(gl,0.04f, 0.30f);
			}
		}
	}

	// Draw Game play End...........??????

	// for draw score,player and over start........?????

	void DrawScore(GL10 gl) {
		mGr.mImg_scoreBar.drawPos(gl, -0.7f, 0.62f);
		mGr.mText_Score.drawPos(gl, -0.87f, 0.69f);
		mGr.mText_Overleft.drawPos(gl, -0.81f, 0.63f);
		{
			if (mGr.over == 10) {
				mGr.mText_number[1].drawPos(gl, -0.6f, 0.63f);
				mGr.mText_number[0].drawPos(gl, -0.57f, 0.63f);
				mGr.mDot.drawPos(gl, -0.55f, 0.815f);
				mGr.mText_number[0].drawPos(gl, -0.53f, 0.63f);
			} else if (mGr.overA == 0 && mGr.overB == 0) {
				mGr.over = 10;
			} else {
				mGr.mText_number[mGr.overA].drawPos(gl, -0.6f, 0.63f);
				mGr.mDot.drawPos(gl, -0.57f, 0.81f);
				mGr.mText_number[mGr.overB].drawPos(gl, -0.55f, 0.63f);
			}
		}
		mGr.mText_Playerleft.drawPos(gl, -0.79f, 0.57f);

		mGr.mText_number[mGr.player].drawPos(gl, -0.6f, 0.57f);

		mGr.mText_Zero.drawPos(gl, -0.58f, 0.69f);
		mGr.mText_Zero.drawPos(gl, -0.53f, 0.69f);
		if (mGr.mScore > 9) {
			mGr.mScore1++;
			mGr.mScore = 0;
		}
		if (mGr.mScore1 > 9) {
			mGr.mScore2++;
			mGr.mScore = 0;
			mGr.mScore1 = 0;
		}
		if (mGr.mScore1 > 0) {
			mGr.mText_number[mGr.mScore1].drawPos(gl, -0.66f, 0.69f);
			mGr.mText_number[mGr.mScore].drawPos(gl, -0.63f, 0.69f);
		} else if (mGr.mScore2 > 0) {
			mGr.mText_number[mGr.mScore1].drawPos(gl, -0.66f, 0.69f);
			mGr.mText_number[mGr.mScore].drawPos(gl, -0.63f, 0.69f);
			mGr.mText_number[mGr.mScore2].drawPos(gl, -0.69f, 0.69f);
		} else {
			mGr.mText_number[mGr.mScore].drawPos(gl, -0.63f, 0.69f);
		}
	}

	// for draw score,player and over end........???????

	// for keeper start.........???

	void DrawKeeper(GL10 gl) {
		if (mGr.setBatssman == true) {
			if (mGr.xline >= -0.09 && mGr.xline < 0) {
				mGr.mImg_keeper[1].drawPos(gl, -0.001f, 0.32f);
			} else if (mGr.xline < -0.1f) {
				mGr.mImg_keeper[5].drawPos(gl, -0.001f, 0.32f);
			} else if (mGr.xline < -0.09f && mGr.xline > -0.1) {
				mGr.mImg_keeper[4].drawPos(gl, -0.001f, 0.32f);
			} else if (mGr.xline > 0 && mGr.xline < 0.18f) {
				mGr.mImg_keeper[2].drawPos(gl, -0.001f, 0.32f);
			} else if (mGr.xline > 0.018f) {
				mGr.mImg_keeper[3].drawPos(gl, -0.001f, 0.32f);
			} else {
				mGr.mImg_keeper[0].drawPos(gl, -0.001f, 0.32f);
			}
		} else {
			mGr.mImg_keeper[0].drawPos(gl, -0.001f, 0.32f);
		}
	}

	// End of keeper..............???

	// start blood spot on player..........???

	void Drawblood1(GL10 gl) {
		if (mGr.blood < 3) {
			// mGr.mImg_player1[mGr.countX1/18%2].drawPos(gl, 0.1f, 0.29f);
		}
		if (mGr.blood == 3) {
			mGr.counterstop++;
		}
		if (forblood1 == true) {
			switch (mGr.blood) {
			case 1:

				mGr.mImg_blood1.drawScal1(gl, Scalvalue, 0.17f, 0.32f);
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				break;
			case 2:
				// mGr.mImg_player1[mGr.countX1/18%2].drawPos(gl, 0.1f, 0.29f);
				mGr.mImg_blood1.drawScal1(gl, Scalvalue, 0.17f, 0.32f);
				mGr.mImg_blood3.drawScal1(gl, Scalvalue, 0.17f, 0.32f);
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				break;
			case 3:
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				mGr.betsman++;
				if (mGr.betsman > 6) {
					mGr.betsman = 0;
					if (mGr.counterd <= 3) {
						mGr.counterd++;
					}
					if (mGr.counterstar <= 1) {
						mGr.counterstar++;
					} else {
						mGr.counterstar = 0;
					}
				}
				mGr.mImg_pDeth[mGr.counterd].drawPos(gl, 0.3f, 0.29f);
				if (mGr.counterd > 2) {
					mGr.mImg_Star[mGr.counterstar].drawPos(gl, 0.52f, 0.25f);
				}
				counterdeth++;
				mGr.ballvari = false;
				if (mGr.counterstop > 30) {
					mGr.player--;
					forblood1 = false;
					forblood2 = false;
					forblood3 = false;
					forblood4 = false;
					hospitalVar = true;
					mGr.setBatssman = false;
					mGr.blood = 0;
					counterdeth = 0;
					mGr.counterd = 0;
					mGr.counterstop = 0;
					resetball();
				}
				break;
			}
		} else {
		}
		if (forblood2 == true) {
			switch (mGr.blood) {
			case 1:
				mGr.mImg_blood1.drawScal1(gl, Scalvalue, 0.09f, 0.365f);
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				break;
			case 2:
				mGr.mImg_blood1.drawScal1(gl, Scalvalue, 0.09f, 0.365f);
				mGr.mImg_blood3.drawScal1(gl, Scalvalue, 0.09f, 0.363f);
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				break;
			case 3:
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				mGr.betsman++;
				if (mGr.betsman > 6) {
					mGr.betsman = 0;
					if (mGr.counterd <= 3) {
						mGr.counterd++;
					}
					if (mGr.counterstar <= 1) {
						mGr.counterstar++;
					} else {
						mGr.counterstar = 0;
					}
				}
				mGr.mImg_pDeth[mGr.counterd].drawPos(gl, 0.3f, 0.29f);
				if (mGr.counterd > 2) {
					mGr.mImg_Star[mGr.counterstar].drawPos(gl, 0.52f, 0.25f);
				}
				counterdeth++;
				mGr.ballvari = false;
				if (mGr.counterstop > 30) {
					mGr.player--;
					forblood1 = false;
					forblood2 = false;
					forblood3 = false;
					forblood4 = false;
					hospitalVar = true;
					mGr.setBatssman = false;
					mGr.blood = 0;
					counterdeth = 0;
					mGr.counterstop = 0;
					mGr.counterd = 0;
					resetball();
				}

				break;
			}
		} else {
		}
		if (forblood3 == true) {
			switch (mGr.blood) {
			case 1:
				mGr.mImg_blood1.drawScal1(gl, Scalvalue, 0.08f, 0.325f);
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				break;
			case 2:
				mGr.mImg_blood1.drawScal1(gl, Scalvalue, 0.08f, 0.325f);
				mGr.mImg_blood3.drawScal1(gl, Scalvalue, 0.08f, 0.325f);
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				break;
			case 3:
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				mGr.betsman++;
				if (mGr.betsman > 6) {
					mGr.betsman = 0;
					if (mGr.counterd <= 3) {
						mGr.counterd++;
					}
					if (mGr.counterstar <= 1) {
						mGr.counterstar++;
					} else {
						mGr.counterstar = 0;
					}
				}
				mGr.mImg_pDeth[mGr.counterd].drawPos(gl, 0.3f, 0.29f);
				if (mGr.counterd > 2) {
					mGr.mImg_Star[mGr.counterstar].drawPos(gl, 0.52f, 0.25f);
				}
				counterdeth++;
				mGr.ballvari = false;
				if (mGr.counterstop > 30) {
					mGr.player--;
					forblood1 = false;
					forblood2 = false;
					forblood3 = false;
					forblood4 = false;
					mGr.setBatssman = false;
					hospitalVar = true;
					mGr.blood = 0;
					counterdeth = 0;
					mGr.counterd = 0;
					mGr.counterstop = 0;
					resetball();
				}

				break;
			}
		} else {
		}
		if (forblood4 == true) {
			switch (mGr.blood) {
			case 1:
				mGr.mImg_blood1.drawScal1(gl, Scalvalue, 0.06f, 0.39f);
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				break;
			case 2:
				mGr.mImg_blood1.drawScal1(gl, Scalvalue, 0.06f, 0.39f);
				mGr.mImg_blood2.drawScal1(gl, Scalvalue, 0.06f, 0.39f);
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				break;
			case 3:
				if (M.setValue == true) {
					M.BloodSound(mGr.mContext, R.drawable.ingame_loop);
				}
				mGr.betsman++;
				if (mGr.betsman > 6) {
					mGr.betsman = 0;
					if (mGr.counterd <= 3) {
						mGr.counterd++;
					}
					if (mGr.counterstar <= 1) {
						mGr.counterstar++;
					} else {
						mGr.counterstar = 0;
					}
				}
				mGr.mImg_pDeth[mGr.counterd].drawPos(gl, 0.3f, 0.29f);
				if (mGr.counterd > 2) {
					mGr.mImg_Star[mGr.counterstar].drawPos(gl, 0.52f, 0.25f);
				}
				mGr.ballvari = false;
				counterdeth++;
				if (mGr.counterstop > 30) {
					mGr.player--;
					forblood1 = false;
					forblood2 = false;
					forblood3 = false;
					forblood4 = false;
					mGr.setBatssman = false;
					hospitalVar = true;
					mGr.blood = 0;
					counterdeth = 0;
					mGr.counterd = 0;
					mGr.counterstop = 0;
					resetball();
				}
				break;
			}
		}
	}

	// //End blood spot on player..........???

	// hospital image start........??????
	void DrawHospital(GL10 gl) {

		if (hospital < 7) {
			mGr.mImg_HospitalBg.draw(gl);
			hospitalx -= 0.2f;
			mGr.mImg_Hospital[hospital].drawPos(gl, hospitalx, 0.1f);
		} else {
			hospitalVar = false;
			hospitalx = 1f;
		}
		try {
			t.sleep(150);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// hospital image end.....?????????

	// x line move Logic start.........??????

	void selectionLogic() {
		boolean line = false;
		boolean line2 = false;
		if (mGr.mLevel == 1) {
			if (mGr.throw_ball.x > -0.17f && select == false && line == false
					&& vari == true) {
				mGr.xline = mGr.throw_ball.x -= 0.0022f;
			} else {
				cntr++;
				vari = false;
				mGr.xline = mGr.throw_ball.x += 0.0022f;
				if (cntr > 193) {
					cntr = 0;
					vari = true;
				}
				// lineReset();
			}

		} else if (mGr.mLevel == 2) {
			if (mGr.throw_ball.x > -0.17f && select == false && vari == true) {
				mGr.xline = mGr.throw_ball.x -= 0.0031f;
			} else {
				cntr++;
				vari = false;
				mGr.xline = mGr.throw_ball.x += 0.0031f;
				if (cntr > 130) {
					cntr = 0;
					vari = true;
				}
				// lineReset();
			}
		} else if (mGr.mLevel == 3) {
			if (mGr.throw_ball.x > -0.17f && select == false && vari == true) {
				mGr.xline = mGr.throw_ball.x -= 0.0034f;
			} else {
				cntr++;
				vari = false;
				mGr.xline = mGr.throw_ball.x += 0.0034f;
				if (cntr > 117) {
					cntr = 0;
					vari = true;
				}
				// lineReset();
			}
		}
	}

	void lineReset() { // for reset x line......??????
		mGr.xline = mGr.throw_ball.x = 0.25f;
	}

	// x line move Logic End.........??????

	// y line move Logic start.........??????

	void selectionLogic1() {
		if (mGr.mLevel == 1) {
			if (mGr.throw_ball.y > 0.15f && select1 == true && variX == true) {
				mGr.yline = mGr.throw_ball.y -= 0.0022f;
			} else {
				mGr.cntrX++;
				variX = false;
				mGr.yline = mGr.throw_ball.y += 0.0022f;
				if (mGr.cntrX > 130) {
					mGr.cntrX = 0;
					variX = true;
				}
				// lineReset1();
			}
		} else if (mGr.mLevel == 2) {
			if (mGr.throw_ball.y > 0.15f && select1 == true && variX == true) {
				mGr.yline = mGr.throw_ball.y -= 0.0031f;
			} else {
				mGr.cntrX++;
				variX = false;
				mGr.yline = mGr.throw_ball.y += 0.0031f;
				if (mGr.cntrX > 95) {
					mGr.cntrX = 0;
					variX = true;
				}
				// lineReset1();
			}
		} else if (mGr.mLevel == 3) {
			if (mGr.throw_ball.y > 0.15f && variX == true) {
				mGr.yline = mGr.throw_ball.y -= 0.0034f;
			} else {
				mGr.cntrX++;
				variX = false;
				mGr.yline = mGr.throw_ball.y += 0.0034f;
				if (mGr.cntrX > 85) {
					mGr.cntrX = 0;
					variX = true;
				}
				// lineReset1();
			}
		}
	}

	// y line move Logic end.........??????

	void lineReset1() { // for reset y line.....????
		mGr.yline = mGr.throw_ball.y = 0.45f;

	}

	// balling Logic start.........????

	void ballingLogic(GL10 gl) {
		if (bally < mGr.yline && bally < 0f) {
			bally += 0.014f;
			ballx += 0.024f;
			mGr.setBatssman = true;
		} else if (bally < mGr.yline && mGr.xline < ballx) {
			mGr.setKeeper = true;
			bally += 0.013f;
			ballx -= 0.0042f;
		} else if (bally < mGr.yline && mGr.xline > ballx) {
			mGr.setKeeper = true;
			bally += 0.016f;
			ballx += 0.0108f;
		} else if (setShot) {
			switch (a) {
			case 1:
				if (ballx > -1.0f) {
					ballx -= 0.04f;
				} else {
					resetball();
				}
				break;
			case 2:
				if (ballx > -1.0f) {
					ballx -= 0.04f;
				} else {
					resetball();
				}
				break;
			case 3:
				if (ballx > -1.0f) {
					ballx -= 0.04f;
				} else {
					resetball();
				}
				break;
			case 4:
				if (ballx < 1.0f) {
					// bally -= 0.03f;
					ballx += 0.051f;
				} else {
					resetball();
				}
				break;
			case 5:
				if (ballx < 1.0f) {
					ballx += 0.05f;
				} else {
					resetball();
				}
				break;
			case 6:
				if (ballx < 1.0f) {
					ballx += 0.055f;
					bally += 0.021f;
				} else {
					resetball();
				}
				break;
			case 7:
				mGr.addbld++;
				forblood1 = true;
				if (mGr.addbld < 2) {
					bloodAdd(gl);
				}
				if (mGr.blood < 3) {
					resetball();
				}
				Drawblood1(gl);

				break;
			case 8:
				mGr.addbld++;
				forblood2 = true;
				if (mGr.addbld < 2) {
					bloodAdd(gl);
				}
				if (mGr.blood < 3) {
					resetball();
				}
				Drawblood1(gl);
				break;
			case 9:
				mGr.addbld++;
				forblood3 = true;
				if (mGr.addbld < 2) {
					bloodAdd(gl);
				}
				if (mGr.blood < 3) {
					resetball();
				}
				Drawblood1(gl);
				break;
			case 10:
				mGr.addbld++;
				forblood4 = true;
				if (mGr.addbld < 2) {
					bloodAdd(gl);
				}
				if (mGr.blood < 3) {
					resetball();
				}
				Drawblood1(gl);
				break;
			case 11:
				resetball();
				break;
			case 12:
				resetball();
				break;
			}
		} else {
			resetball();
		}
	}

	// balling Logic end.........,,,,,,,,,,,????

	void bloodAdd(GL10 gl) {
		if (mGr.blood < 3) {
			mGr.blood++;
		}

		mGr.mScore += 1;

	}

	// reset all values......,,,,,,,,,,,,,,,,,???

	void resetball() {
		try {
			t.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mGr.abcd = 0;
		mGr.addbld = 0;
		select2 = false;
		lineReset();
		lineReset1();
		mGr.setBatssman = false;
		mGr.setKeeper = false;
		vari = true;
		variX = true;
		mGr.ballvari = true;
		cntr = 0;
		mGr.countX11 = 0;
		mGr.cntrX = 0;
		setbat = 0;
		a = 0;
		counter = 0;
		counter1 = 0;
		abc = 0;
		hospital = 0;
		abc1 = 0;
		mx = -0.29f;
		my = 0.62f;
		mx1 = -0.39f;
		my1 = -0.75f;
		select = false;
		select1 = false;
		setShot = false;
		bally = -0.07f;
		ballx = -0.18f;
		mGr.over--;
		if (mGr.overB == 0) {
			mGr.overA--;
			mGr.overB = 5;
		} else {
			mGr.overB--;
		}
		if (mGr.overA == 0 && mGr.overB == 0) {
			M.GameScreen = M.PlayAgain;
			mGr.overA = 9;
			mGr.over = 10;
			mGr.overB = 5;
			mGr.player = 3;
			mGr.mScore = 0;
			mGr.mScore1 = 0;
			mGr.mScore2 = 0;
			mGr.blood = 0;
		}
		if (mGr.player == 0 && mGr.mLevel == 1) {
			M.GameScreen = M.GameWinMidium;
			mGr.player = 3;
			mGr.over = 10;
			mGr.mScore = 0;
			mGr.mScore1 = 0;
			mGr.mScore2 = 0;
			mGr.overA = 9;
			mGr.overB = 5;
			mGr.blood = 0;
		} else if (mGr.player == 0 && mGr.mLevel == 2) {
			M.GameScreen = M.GameWinHard;
			mGr.player = 3;
			mGr.over = 10;
			mGr.mScore = 0;
			mGr.mScore1 = 0;
			mGr.mScore2 = 0;
			mGr.overA = 9;
			mGr.overB = 5;
			mGr.blood = 0;
		} else if (mGr.player == 0 && mGr.mLevel == 3) {
			M.GameScreen = M.PlayAgain;
			mGr.player = 3;
			mGr.over = 10;
			mGr.mScore = 0;
			mGr.mScore1 = 0;
			mGr.mScore2 = 0;
			mGr.overA = 9;
			mGr.overB = 5;
			mGr.blood = 0;
		}
	}

	// drawing side bowler........??????

	void DrawBoller(GL10 gl) {
		if (abc < 8) {
			mGr.image[abc].drawPos(gl, mx, my);
			mx += 0.1f;
			try {
				t.sleep(90);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// drawing main bowler........??????

	void DrawBoller1(GL10 gl) {
		if (abc > 7 && abc1 < 22) {
			mGr.mImg_bowler[abc1].drawPos(gl, mx1, my1);
			my1 += 0.04f;
			try {
				t.sleep(90);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// end bowler........??????

	void SaveGameScore() {
		SharedPreferences prefs = mGr.mStart.getSharedPreferences("X",
				Start.MODE_PRIVATE);
		Editor editor = prefs.edit();

		if (mGr.mLevel == 1 && (mGr.mHighScoreWicket1 < mGr.mScore)) {
			mGr.mHighScoreWicket1 = mGr.mScore;
			editor.putInt("mHighScoreWicket1", mGr.mHighScoreWicket1);
		}
		if (mGr.mLevel == 5 && (mGr.mHighScoreWicket5 < mGr.mScore)) {
			mGr.mHighScoreWicket5 = mGr.mScore;
			editor.putInt("mHighScoreWicket5", mGr.mHighScoreWicket5);
		}
		if (mGr.mLevel == 11 && (mGr.mHighScoreWicket11 < mGr.mScore)) {
			mGr.mHighScoreWicket11 = mGr.mScore;
			editor.putInt("mHighScoreWicket11", mGr.mHighScoreWicket11);
		}
		editor.commit();
	}

	void SetBall() {

		mGr.countValue = 0;
		Flag = true;
		Balldown = false;
		setStumps = false;
		ballHit = false;
		mGr.throw_ball.x = 1.0f;
		mGr.throw_ball.y = -0.1f;
		mGr.countX1 = mGr.countX2 = mGr.countW1 = 0;
		boundary6 = boundary4 = boundary3 = boundary2 = boundary1 = false;
	}

	float RandomRangeF(float fMin, float fMax) {
		float frange = fMax - fMin + 0.02f;
		float frandomNum = mGr.mfRand.nextFloat() * frange;
		return frandomNum;
	}

	public boolean TouchEvent(MotionEvent event) {
		switch (M.GameScreen) {
		case M.GameSplash:
			HandleSplash(event);
			break;
		case M.GameSubSplash:
			HandleSubSplash(event);
			break;

		case M.GameMenu:
			HandleMenu(event);
			break;
		case M.GamePause:
		case M.GamePlay:
			HandleGamePlay(event);
			break;
		case M.GameOver:
			HandleGameOver(event);
			break;

		// HandleGamePause(event);

		case M.PlayAgain:
			HandlePlayAgain(event);
			break;
		case M.GameWinMidium:
			HandleWinMidium(event);
			break;
		case M.GameWinHard:
			HandleWinHard(event);
			break;
		}
		return true;
	}

	boolean HandleSplash(MotionEvent event) {
		if (CircRectsOverlap(0.88f, -0.85f, mGr.mImg_play.width() / 2,
				mGr.mImg_play.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mSel = 1;
		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			switch (mGr.mSel) {
			case 1:
				M.GameScreen = M.GameMenu;
				mGr.mSel = 0;
				break;
			}
		}
		return true;
	}

	// boolean HandleSelection(MotionEvent event){
	// CircRectsOverlap(0.7f, -1f, mGr.mImg_selectIcon.width()/2,
	// mGr.mImg_selectIcon.Height()/2, screen2worldX(event.getX()),
	// screen2worldY(event.getY()), .05f);
	//
	// if (event.getAction() == MotionEvent.ACTION_UP) {
	//
	// }
	//
	// return true;
	// }
	boolean HandleSubSplash(MotionEvent event) {
		if (CircRectsOverlap(-0.25f, 0.0f, mGr.mImg_day.width() / 2,
				mGr.mImg_day.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mSel = 1;
		}
		if (CircRectsOverlap(+0.25f, 0.0f, mGr.mImg_night.width() / 2,
				mGr.mImg_night.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mSel = 2;
		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			if (CircRectsOverlap(-0.25f, 0.0f, mGr.mImg_day.width() / 2,
					mGr.mImg_day.Height() / 2, screen2worldX(event.getX()),
					screen2worldY(event.getY()), .05f)) {
				gameBg = 0;
				M.GameScreen = M.GameMenu;
				mGr.mSel = 0;
			}
			if (CircRectsOverlap(+0.25f, 0.0f, mGr.mImg_night.width() / 2,
					mGr.mImg_night.Height() / 2, screen2worldX(event.getX()),
					screen2worldY(event.getY()), .05f)) {
				gameBg = 1;
				M.GameScreen = M.GameMenu;
				mGr.mSel = 0;
			}
			mGr.mSel = 0;
		}
		return true;
	}

	boolean HandleWinMidium(MotionEvent event) {
		if (CircRectsOverlap(0.745f, -0.515f, mGr.mImg_play.width() / 2,
				mGr.mImg_play.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mSel = 1;
		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			switch (mGr.mSel) {
			case 1:
				if (CircRectsOverlap(0.745f, -0.515f,
						mGr.mImg_play.width() / 2, mGr.mImg_play.Height() / 2,
						screen2worldX(event.getX()),
						screen2worldY(event.getY()), .05f)) {
					M.GameScreen = M.GamePlay;
					mGr.mLevel = 2;
				}
				mGr.mSel = 0;
				break;

			}
		}
		return true;
	}

	boolean HandleWinHard(MotionEvent event) {
		if (CircRectsOverlap(0.738f, -0.518f, mGr.mImg_play.width() / 2,
				mGr.mImg_play.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mSel = 1;
		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			switch (mGr.mSel) {
			case 1:
				if (CircRectsOverlap(0.738f, -0.518f,
						mGr.mImg_play.width() / 2, mGr.mImg_play.Height() / 2,
						screen2worldX(event.getX()),
						screen2worldY(event.getY()), .05f)) {
					M.GameScreen = M.GamePlay;
					mGr.mLevel = 3;
				}
				mGr.mSel = 0;
				break;

			}
		}
		return true;
	}

	boolean HandleMenu(MotionEvent event) {
		if (CircRectsOverlap(0.0f, 0.22f, mGr.mImg_easy.width() / 2,
				mGr.mImg_easy.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mMenusel = 1; // easy
		}
		if (CircRectsOverlap(0.0f, -0.001f, mGr.mImg_medium.width() / 2,
				mGr.mImg_medium.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mMenusel = 2; // medium
		}
		if (CircRectsOverlap(0f, -0.22f, mGr.mImg_hard.width() / 2,
				mGr.mImg_hard.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mMenusel = 3; // hard
		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			switch (mGr.mMenusel) {
			case 1:
				if (CircRectsOverlap(0f, 0.22f, mGr.mImg_easy1.width() / 2,
						mGr.mImg_easy1.Height() / 2,
						screen2worldX(event.getX()),
						screen2worldY(event.getY()), .05f)) {
					mGr.mLevel = 1;
					mGr.mWickets = 1;
					vari = true;
					variX = true;
					cntr = 0;
					mGr.setKeeper = false;
					mGr.setBatssman = false;
					mGr.avari = 0;
					mGr.counterd = 0;
					mGr.counterstar = 0;
					mGr.betsman = 0;
					mGr.speedup = 0;
					mGr.maxpower = 0;
					mGr.addbld = 0;
					mGr.cntrX = 0;
					lineReset();
					lineReset1();
					vari = true;
					variX = true;
					cntr = 0;
					mGr.countX11 = 0;
					mGr.cntrX = 0;
					setbat = 0;
					a = 0;
					counter = 0;
					counter1 = 0;
					abc = 0;
					hospital = 0;
					abc1 = 0;
					mx = -0.29f;
					my = 0.62f;
					mx1 = -0.39f;
					my1 = -0.75f;
					select = false;
					select1 = false;
					setShot = false;
					bally = -0.07f;
					ballx = -0.18f;
					mGr.blood = 0;
					forblood1 = false;
					forblood2 = false;
					forblood3 = false;
					forblood4 = false;
					M.GameScreen = M.GamePlay;
				}
				break;
			case 2:
				if (CircRectsOverlap(0.0f, -0.001f,
						mGr.mImg_medium1.width() / 2,
						mGr.mImg_medium1.Height() / 2,
						screen2worldX(event.getX()),
						screen2worldY(event.getY()), .05f)) {
					mGr.mLevel = 2;
					vari = true;
					variX = true;
					cntr = 0;
					mGr.setKeeper = false;
					mGr.addbld = 0;
					mGr.setBatssman = false;
					mGr.avari = 0;
					mGr.counterd = 0;
					mGr.counterstar = 0;
					mGr.betsman = 0;
					mGr.speedup = 0;
					mGr.maxpower = 0;

					mGr.blood = 0;
					mGr.cntrX = 0;
					lineReset();
					lineReset1();
					vari = true;
					variX = true;
					cntr = 0;
					forblood1 = false;
					forblood2 = false;
					forblood3 = false;
					forblood4 = false;
					mGr.countX11 = 0;
					mGr.cntrX = 0;
					setbat = 0;
					a = 0;
					counter = 0;
					counter1 = 0;
					abc = 0;
					hospital = 0;
					abc1 = 0;
					mx = -0.29f;
					my = 0.62f;
					mx1 = -0.39f;
					my1 = -0.75f;
					select = false;
					select1 = false;
					setShot = false;
					bally = -0.07f;
					ballx = -0.18f;
					mGr.mWickets = 5;
					M.GameScreen = M.GamePlay;
				}
				break;
			case 3:
				if (CircRectsOverlap(0.0f, -0.22f, mGr.mImg_hard1.width() / 2,
						mGr.mImg_hard1.Height() / 2,
						screen2worldX(event.getX()),
						screen2worldY(event.getY()), .05f)) {
					mGr.mLevel = 3;
					mGr.mWickets = 11;
					vari = true;
					variX = true;
					mGr.addbld = 0;
					mGr.setKeeper = false;
					mGr.setBatssman = false;
					mGr.avari = 0;
					mGr.counterd = 0;
					mGr.counterstar = 0;
					mGr.betsman = 0;
					mGr.speedup = 0;
					mGr.maxpower = 0;

					forblood1 = false;
					forblood2 = false;
					forblood3 = false;
					forblood4 = false;
					cntr = 0;
					mGr.blood = 0;
					mGr.cntrX = 0;
					lineReset();
					lineReset1();
					vari = true;
					variX = true;
					cntr = 0;
					mGr.countX11 = 0;
					mGr.cntrX = 0;
					setbat = 0;
					a = 0;
					counter = 0;
					counter1 = 0;
					abc = 0;
					hospital = 0;
					abc1 = 0;
					mx = -0.29f;
					my = 0.62f;
					mx1 = -0.39f;
					my1 = -0.75f;
					select = false;
					select1 = false;
					setShot = false;
					bally = -0.07f;
					ballx = -0.18f;
					M.GameScreen = M.GamePlay;
				}
				break;
			}
			mGr.mMenusel = 0;
		}
		return true;
	}

	boolean HandlePlayAgain(MotionEvent event) {

		if (CircRectsOverlap(0.0f, -0.2f, mGr.mImg_playAgain.width() / 2,
				mGr.mImg_playAgain.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .02f)) {
			mGr.mSel = 1;

		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			switch (mGr.mSel) {
			case 1:
				M.GameScreen = M.GameMenu;
				mGr.GameReset();
				mGr.mSel = 0;
			}
		}
		return true;
	}

	boolean HandleGamePause(MotionEvent event) {

		float disX2 = -0.2f;
		if (CircRectsOverlap(0.7f + disX2, 0.6f, mGr.mImg_soundOn.width() / 2,
				mGr.mImg_soundOn.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .02f)) {
			mGr.mSel = 1; // sound
		}
		if (CircRectsOverlap(0.79f + disX2, -0.9f,
				mGr.mImg_pause[0].width() / 2, mGr.mImg_pause[0].Height() / 2,
				screen2worldX(event.getX()), screen2worldY(event.getY()), .02f)) {
			mGr.mSel = 2; // play
		}
		if (CircRectsOverlap(0.935f + disX2, -0.9f,
				mGr.mImg_reset[0].width() / 2, mGr.mImg_reset[0].Height() / 2,
				screen2worldX(event.getX()), screen2worldY(event.getY()), .02f)) {
			mGr.mSel = 3; // reset
		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			switch (mGr.mSel) {
			case 1:
				if (M.setValue == true)
					M.setValue = false;
				else
					M.setValue = true;
				mGr.mSel = 0;
				break;
			case 2:
				if (M.setValue1 == true) {
					M.GameScreen = M.GamePlay;
					M.setValue1 = false;
				} else {
					M.GameScreen = M.GamePause;
					M.setValue1 = true;
				}
				mGr.mSel = 0;
				break;
			case 3:
				M.GameScreen = M.GamePlay;
				mGr.mWickets = mGr.mLevel;
				if (M.setValue1 == true) {
					M.setValue1 = false;
				} else {
					M.setValue1 = true;
				}
				mGr.mScore = 0;
				mGr.mSel = 0;
				break;
			}
		}
		return true;
	}

	boolean HandleGameOver(MotionEvent event) {

		if (CircRectsOverlap(-0.4f, -0.25f, mGr.mImg_button.width() / 2,
				mGr.mImg_button.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mMenusel = 1; // play again
		}
		if (CircRectsOverlap(0.4f, -0.25f, mGr.mImg_button.width() / 2,
				mGr.mImg_button.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mMenusel = 2; // exit
		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			switch (mGr.mMenusel) {
			case 1:
				if (CircRectsOverlap(-0.4f, -0.25f,
						mGr.mImg_button.width() / 2,
						mGr.mImg_button.Height() / 2,
						screen2worldX(event.getX()),
						screen2worldY(event.getY()), .05f)) {
					M.GameScreen = M.GameMenu;
					SaveGameScore();
					mGr.GameReset();

					Balldown = false;
					setStumps = false;
					setShots = false;
					deth = true;
				}
				break;
			case 2:
				if (CircRectsOverlap(0.4f, -0.25f, mGr.mImg_button.width() / 2,
						mGr.mImg_button.Height() / 2,
						screen2worldX(event.getX()),
						screen2worldY(event.getY()), .05f)) {
					SaveGameScore();
					mGr.mStart.get();
				}
				break;
			}
			mGr.mMenusel = 0;
		}
		return true;
	}

	boolean HandleGamePlay(MotionEvent event) {

		if (CircRectsOverlap(0.79f, -0.9f, mGr.mImg_selectIcon.width() / 2,
				mGr.mImg_selectIcon.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {

			mGr.mSel = 1;

		}
		if (CircRectsOverlap(0.79f, 0.9f, mGr.mImg_soundOn.width() / 2,
				mGr.mImg_soundOn.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mSel = 2;
		}
		if (CircRectsOverlap(-0.79f, -0.9f, mGr.mImage_pause.width() / 2,
				mGr.mImage_pause.Height() / 2, screen2worldX(event.getX()),
				screen2worldY(event.getY()), .05f)) {
			mGr.mSel = 3;
		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			switch (mGr.mSel) {
			case 1:
				if (mGr.mLevel == 3) {
					select2 = true;
				} else {
					select2 = false;
				}
				if (select == false) {
					select = true;
					setBlood = true;
					select1 = true;
				} else {
					select1 = false;
				}
				mGr.mSel = 0;
				break;
			case 2:
				if (M.setValue == true)
					M.setValue = false;
				else
					M.setValue = true;
				mGr.mSel = 0;
				break;
			case 3:
				if (M.setValue11 == true) {
					M.setValue11 = false;
					mGr.ballvari = false;
					M.GameScreen = M.GamePause;
				} else {
					mGr.ballvari = true;
					M.setValue11 = true;
					M.GameScreen = M.GamePlay;
				}
				mGr.mSel = 0;
			}

		}

		return true;
	}

	void drawImg(GL10 gl, SimplePlane tex, float x, float y) {
		tex.drawPos(gl, x, y);
	}

	void drawImgScale(GL10 gl, SimplePlane tex, float Scal, float x, float y) {
		tex.drawScal(gl, Scal, Scal, x, y);
	}

	float getWidth(float width) {
		return width * (M.mMaxX / 2);
	}

	float getHeight(float Height) {
		return Height * (M.mMaxY / 2);
	}

	void DrawTexture(GL10 gl, SimplePlane tex, float x, float y) {
		if (x > 0 - getWidth(tex.width())
				&& x <= M.mMaxX + getWidth(tex.width() / 2))
			tex.drawPos(gl, XPos(x), YPos(y));
	}

	float XPos(float x) {
		return screen2worldX(x * (M.ScreenWidth / M.mMaxX));
	}

	float YPos(float y) {
		return screen2worldY(y * (M.ScreenHieght / M.mMaxY));
	}

	boolean CircRectsOverlap(double CRX, double CRY, double CRDX, double CRDY,
			double centerX, double centerY, double radius) {
		if ((Math.abs(centerX - CRX) <= (CRDX + radius))
				&& (Math.abs(centerY - CRY) <= (CRDY + radius)))
			return true;
		return false;
	}

	float screen2worldX(float a) {
		float c = ((a / M.ScreenWidth) - 0.5f) * 2;
		return c;
	}

	float screen2worldY(float a) {
		float c = ((a / M.ScreenHieght) - 0.5f) * (-2);
		return c;
	}

	public void setListner(AdsListner listner) {
		this.listner = listner;
		
	}
}
