package com.b2w.games.sachincricket.view;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;

import com.b2w.games.sachincricket.LaunchActivity;

public class VortexView extends GLSurfaceView 
{
	public VortexView(Context context) { 
		super(context);
	}
	public VortexView(Context context, AttributeSet attrs) { 
		super(context, attrs);
	}
	public boolean onTouchEvent(final MotionEvent event) {
		return true;
	}
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode, event ); 
	}  
	public boolean onKeyUp(int keyCode, KeyEvent event) {  	
	 	return super.onKeyUp(keyCode, event ); 
	}
}
