package com.b2w.games.sachincricket.view;

public interface AdsListner {
   public void showAds();
}
