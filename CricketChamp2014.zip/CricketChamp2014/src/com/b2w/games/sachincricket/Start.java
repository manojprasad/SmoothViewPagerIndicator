package com.b2w.games.sachincricket;





import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.b2w.games.sachincricket.view.AdsListner;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;



public class Start extends Activity implements AdsListner{
	private static final String LOG_TAG = "CRICKET2014";
	 private static final int WAIT_TIME = 5000;
	 public InterstitialAd interstitialAd;
	GameRender renderer = null;
	private AdView adView;
	private static Context CONTEXT;
	
    protected void onCreate(Bundle savedInstanceState) {
        CONTEXT	=	this;
		M.GameScreen = M.GameLogo;
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_main);
		WindowManager mWinMgr = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
		M.ScreenWidth  = mWinMgr.getDefaultDisplay().getWidth();
		M.ScreenHieght = mWinMgr.getDefaultDisplay().getHeight();
		initInterestialAdd();
		renderer = new GameRender(this);
		renderer.setListner(this);
	    VortexView glSurface=(VortexView) findViewById(R.id.vortexview); // use the xml to set the view
	    glSurface.setRenderer(renderer);
	    glSurface.showRenderer(renderer);
	    callAdds();
    }
    void callAdds() {
		adView = new AdView(this);
		 adView.setAdSize(AdSize.BANNER);
		 adView.setAdUnitId(M.MY_AD_UNIT_ID);
		LinearLayout layout = (LinearLayout)findViewById(R.id.addgame);
        layout.addView(adView);
        AdRequest adRequest = new AdRequest.Builder().build();
       adView.loadAd(adRequest);
	}
   
    public static Context getContext() {
        return CONTEXT;
    }
    
    @Override 
	public void onPause() {
    	 

    	M.stop(CONTEXT);
    	pause();
		super.onPause();
	} 
	@Override 
	public void onResume() {
		
		resume();
		super.onResume();
	}
    void get() {
	   new AlertDialog.Builder(this)
	    .setIcon(R.drawable.icon) //call icon images
	    .setTitle("Do you want to Exit?")
	    .setPositiveButton("Now", new DialogInterface.OnClickListener() {
	    	public void onClick(DialogInterface dialog, int which) {
		       finish();
		    }
		})
		.setNegativeButton("Later", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
		    }
		}).show();
	}
    public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode==KeyEvent.KEYCODE_BACK) {
			switch(M.GameScreen) {			
			}
			return false;
		}
		return super.onKeyDown( keyCode, event ); 
	}  
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		if(keyCode==KeyEvent.KEYCODE_BACK) {
			switch(M.GameScreen) {
				case M.GameLogo:
					get();
					break;
				case M.GameSplash:
					M.GameScreen = M.GameLogo;
					get();
					break;
				case M.GameSubSplash:
					M.GameScreen = M.GameLogo;
					get();
					break;
				case M.GameMenu:
					M.GameScreen = M.GameLogo;
					renderer.mGame.SaveGameScore();
					get();
					break;
				case M.GamePlay:
					M.GameScreen = M.GameMenu;
					renderer.mGame.SaveGameScore();
					renderer.GameReset();
//					renderer.GameReset1();
					renderer.mGame.Balldown = false;
					renderer.mGame.setStumps = false;
					renderer.mGame.setShots = false;
					break;
				case M.GamePause:
					M.GameScreen = M.GameMenu;
					if(M.setValue1==true) {
						M.setValue1 = false;
				   }else {
						M.setValue1 = true;
				   }
//					if(M.setValue)
//						M.BgSound(renderer.mContext,R.drawable.bounce);
//					else
//						M.BgStop();
					break;
				case M.GameOver:
					M.GameScreen = M.GameMenu;
//					renderer.mGame.SaveGameScore();
					renderer.GameReset();
//					renderer.GameReset1();
					renderer.mGame.Balldown = false;
					renderer.mGame.setStumps = false;
					renderer.mGame.setShots = false;
					break;
				case M.PlayAgain:
					M.GameScreen = M.GameMenu;
					renderer.GameReset();
					
					break;
				case M.GameWinMidium:
					M.GameScreen = M.GameMenu;
					loadInterestialAdd();
					
					break;
				case M.GameWinHard:
					M.GameScreen = M.GameMenu;
					renderer.GameReset();
					
					break;
			}
			return false;
		}
		return super.onKeyUp(keyCode, event); 
	}
	public void onDestroy() {
		super.onDestroy();
	}
	@SuppressLint("CommitPrefEdits")
	void pause() {
		
		M.stop(renderer.mContext);
		M.BgStop();
		SharedPreferences prefs = getSharedPreferences("X",MODE_PRIVATE);
    	Editor editor = prefs.edit();
    	editor.putInt("GameScreen",M.GameScreen);
    	editor.putBoolean("SetValue",M.setValue);
    	editor.putBoolean("SetValue1",M.setValue1);
    	
    	editor.putFloat("BallMin",M.BallMin);
    	editor.putFloat("BallMax",M.BallMax);
    	editor.putFloat("NormalSpeed",M.NormalSpeed);
    	editor.putFloat("TopSpeed1",M.TopSpeed1);
    	editor.putFloat("TopSpeed2",M.TopSpeed2);
    	editor.putFloat("TopSpeed3",M.TopSpeed3);
    	editor.putFloat("Yshotball1",M.Yshotball1);
    	editor.putFloat("Yshotball2",M.Yshotball2);
    	editor.putFloat("Yshotball3",M.Yshotball3);
    	editor.putFloat("Yshotball4",M.Yshotball4);
    	
    	editor.putBoolean("setShots",renderer.mGame.setShots);
    	editor.putBoolean("setStumps",renderer.mGame.setStumps);
    	editor.putBoolean("ballHit",renderer.mGame.ballHit);
    	editor.putBoolean("Balldown",renderer.mGame.Balldown);
    	editor.putBoolean("Flag",renderer.mGame.Flag);
    	
    	editor.putBoolean("boundary6",renderer.mGame.boundary6);
    	editor.putBoolean("boundary6",renderer.mGame.boundary4);
    	editor.putBoolean("boundary6",renderer.mGame.boundary3);
    	editor.putBoolean("boundary6",renderer.mGame.boundary2);
    	editor.putBoolean("boundary6",renderer.mGame.boundary1);
    	
    	editor.putInt("gameBg",renderer.mGame.gameBg);
    	editor.putInt("cnt",renderer.mGame.cnt);
    	editor.putInt("cnt1",renderer.mGame.cnt1);
    	
    	editor.putInt("countP1",renderer.countP1);
    	editor.putInt("countW1",renderer.countW1);
    	editor.putInt("countX1",renderer.countX1);
    	editor.putInt("countX2",renderer.countX2);
    	editor.putInt("countValue",renderer.countValue);
    	
    	editor.putFloat("ySpeed",renderer.ySpeed);
    	editor.putInt("mScore",renderer.mScore);
    	editor.putInt("mScore1",renderer.mScore1);
    	editor.putInt("mScore2",renderer.mScore2);
    	editor.putInt("player",renderer.player);
    	editor.putInt("overA",renderer.overA);
    	editor.putInt("overB",renderer.overB);
    	editor.putInt("mBestScore",renderer.mBestScore);
    	editor.putInt("mWickets",renderer.mWickets);
    	editor.putInt("mLevel",renderer.mLevel);
    	editor.putInt("mLevel",renderer.mHighScoreWicket1);
    	editor.putInt("mLevel",renderer.mHighScoreWicket5);
    	editor.putInt("mLevel",renderer.mHighScoreWicket11);
    	loadInterestialAdd();
	}	
	void resume() {
		
	 	 SharedPreferences prefs = getSharedPreferences("File", MODE_PRIVATE);
	 	 M.GameScreen 	= prefs.getInt("GameScreen",M.GameScreen);
		 M.setValue 	= prefs.getBoolean("SetValue",M.setValue);
		 M.setValue1 	= prefs.getBoolean("SetValue1",M.setValue1);

		 M.BallMax		= prefs.getFloat("BallMax",M.BallMax);
		 M.NormalSpeed	= prefs.getFloat("NormalSpeed",M.NormalSpeed);
		 M.TopSpeed1	= prefs.getFloat("TopSpeed1",M.TopSpeed1);
		 M.TopSpeed2	= prefs.getFloat("TopSpeed2",M.TopSpeed2);
		 M.TopSpeed3 	= prefs.getFloat("TopSpeed3",M.TopSpeed3);
		 M.Yshotball1	= prefs.getFloat("Yshotball1",M.Yshotball1);
		 M.Yshotball2	= prefs.getFloat("Yshotball2",M.Yshotball2);
		 M.Yshotball3	= prefs.getFloat("Yshotball3",M.Yshotball3);
		 M.Yshotball4	= prefs.getFloat("Yshotball4",M.Yshotball4);		 
		 
		 renderer.mGame.setShots = prefs.getBoolean("setShots",renderer.mGame.setShots);
		 renderer.mGame.setStumps = prefs.getBoolean("setStumps",renderer.mGame.setStumps);
		 renderer.mGame.ballHit = prefs.getBoolean("ballHit",renderer.mGame.ballHit);
		 renderer.mGame.Balldown = prefs.getBoolean("Balldown",renderer.mGame.Balldown);
		 renderer.mGame.Flag = prefs.getBoolean("Flag",renderer.mGame.Flag);
	    	
		 renderer.mGame.boundary6 = prefs.getBoolean("boundary6",renderer.mGame.boundary6);
		 renderer.mGame.boundary4 = prefs.getBoolean("boundary6",renderer.mGame.boundary4);
		 renderer.mGame.boundary3 = prefs.getBoolean("boundary6",renderer.mGame.boundary3);
		 renderer.mGame.boundary2 = prefs.getBoolean("boundary6",renderer.mGame.boundary2);
		 renderer.mGame.boundary1 = prefs.getBoolean("boundary6",renderer.mGame.boundary1);
		 
		 renderer.mGame.gameBg = prefs.getInt("gamebg",renderer.mGame.gameBg);
		 renderer.mGame.cnt = prefs.getInt("gamebg",renderer.mGame.cnt);
		 renderer.mGame.cnt = prefs.getInt("gamebg",renderer.mGame.cnt1);
	    	
		 renderer.countP1 = prefs.getInt("countP1",renderer.countP1);
		 renderer.countW1 = prefs.getInt("countW1",renderer.countW1);
		 renderer.countX1 = prefs.getInt("countX1",renderer.countX1);
		 renderer.countX2 = prefs.getInt("countX2",renderer.countX2);
		 renderer.countValue = prefs.getInt("countValue",renderer.countValue);
	    	
		 renderer.ySpeed = prefs.getFloat("ySpeed",renderer.ySpeed);
		 renderer.mScore = prefs.getInt("mScore",renderer.mScore);
		 renderer.mScore1=	prefs.getInt("mScore1",renderer.mScore1);
		 renderer.mScore2=	prefs.getInt("mScore2",renderer.mScore2);
		 renderer.player =	prefs.getInt("player",renderer.player);
		renderer.overA   =	prefs.getInt("overA",renderer.overA);
		renderer.overB   =	prefs.getInt("overB",renderer.overB);
		 renderer.mBestScore = prefs.getInt("mBestScore",renderer.mBestScore);
		 renderer.mWickets = prefs.getInt("mWickets",renderer.mWickets);
		 renderer.mLevel = prefs.getInt("mLevel",renderer.mLevel);
		 renderer.mHighScoreWicket1 = prefs.getInt("mLevel",renderer.mHighScoreWicket1);
		 renderer.mHighScoreWicket5 = prefs.getInt("mLevel",renderer.mHighScoreWicket5);
		 renderer.mHighScoreWicket11 = prefs.getInt("mLevel",renderer.mHighScoreWicket11);
	}	
	
	
	public  void initInterestialAdd(){
	    interstitialAd = new InterstitialAd(this);
	    interstitialAd.setAdUnitId(M.MY_AD_UNIT_ID);

	    // Set the AdListener.
	    interstitialAd.setAdListener(new AdListener() {
	      @Override
	      public void onAdLoaded() {
	    	  if (interstitialAd.isLoaded()) {
	    	      interstitialAd.show();
	    	    } else {
	    	      Log.d(LOG_TAG, "Interstitial ad was not ready to be shown.");
	    	    }
	      }

	      @Override
	      public void onAdFailedToLoad(int errorCode) {
	    	  String message = String.format("onAdFailedToLoad (%s)", getErrorReason(errorCode));
	          Log.d(LOG_TAG, message);
	         // Toast.makeText(Start.this, message, Toast.LENGTH_SHORT).show();
	    	  
	      }
	    });

	}
	
	private void loadInterestialAdd(){
		 AdRequest adRequest = new AdRequest.Builder()
	        .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
	        .addTestDevice("11F7AE3EE079147DC0BC2571D353001C")
	        .build();
	    interstitialAd.loadAd(adRequest);
	}
	
	/** Gets a string error reason from an error code. */
	  private String getErrorReason(int errorCode) {
	    String errorReason = "";
	    switch(errorCode) {
	      case AdRequest.ERROR_CODE_INTERNAL_ERROR:
	        errorReason = "Internal error";
	        break;
	      case AdRequest.ERROR_CODE_INVALID_REQUEST:
	        errorReason = "Invalid request";
	        break;
	      case AdRequest.ERROR_CODE_NETWORK_ERROR:
	        errorReason = "Network Error";
	        break;
	      case AdRequest.ERROR_CODE_NO_FILL:
	        errorReason = "No fill";
	        break;
	    }
	    return errorReason;
	  }
	void SubmitScore() {
	   new AlertDialog.Builder(this)
	    .setIcon(R.drawable.ic_launcher)
	    .setTitle("Submit Score ?")
	    .setPositiveButton("Yes", 
	      new DialogInterface.OnClickListener() {
		       public void onClick(DialogInterface dialog, int which) {
		       }
		      })
		      .setNegativeButton("No", 
		      new DialogInterface.OnClickListener() {
		       
		       @Override
		       public void onClick(DialogInterface dialog, int which) {
		    	   get();
		       }
		      }).show();
	  }


	@Override
	public void showAds() {
		loadInterestialAdd();
		Toast.makeText(this, "Ads Load", Toast.LENGTH_LONG).show();
	}
}