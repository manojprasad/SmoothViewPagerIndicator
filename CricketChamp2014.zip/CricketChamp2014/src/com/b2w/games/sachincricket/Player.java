package com.b2w.games.sachincricket;

public class Player {
	
    float x, y, vx, vy;
    
    void set_ball(float _x,float _y,float _vx,float _vy) {
        x	= _x;
        y	= _y;
        vx	= _vx;
        vy	= _vy;
    }
}
