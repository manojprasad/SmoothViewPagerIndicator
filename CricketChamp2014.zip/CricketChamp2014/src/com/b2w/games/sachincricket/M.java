package com.b2w.games.sachincricket;

import android.content.Context;
import android.media.MediaPlayer;

public class M {
	
	public static final String scores = "scores";
	public static int GameScreen = 0;
	public static float ScreenWidth, ScreenHieght;
	public static final float mMaxX = 480, mMaxY = 800;
	public static final int GameLogo = 0, GameSplash = 1, GameMenu = 2, GameStart = 3, GamePlay = 4;
	public static final int GamePause = 5, GameOver = 6, GameSubSplash = 7,PlayAgain=8,GameWinMidium=9,GameWinHard=10;
	public static boolean setValue		= true;
	public static boolean setValue1		= false;
	public static boolean setValue11		= true;
	public static final String MY_AD_UNIT_ID = "ca-app-pub-2553064383187742/8190684919"; // Ad Mob

	public static float TopSpeed1    	= 0.057f;
	public static float TopSpeed2    	= 0.055f;
	public static float TopSpeed3    	= 0.055f;
		
	public static float Yshotball1    	= 0.005f;
    public static float Yshotball2    	= 0.0285f;
    public static float Yshotball3    	= 0.04f;
    public static float Yshotball4    	= 0.048f;
    
    public static float NormalSpeed 	= 0.0035f;
        
    public static float BallMin     	= 0.0183f;
    public static float BallMax     	= 0.035f;
   
    public static final float BallEndX  = -0.17f;
    public static final float BallEndY  = -0.65f;
    
    public static final float BallStartX= 0.25f;
    public static final float BallStartY= -0.65f;
    
    private static MediaPlayer mpEffect0 = null, mpEffect1 = null, mpEffect2 = null;
    public static void GameSound(Context context)
	{
		try{
			if(mpEffect0==null)
				mpEffect0 = MediaPlayer.create(context, R.drawable.introloop_0001);
		
			if(mpEffect1==null)
				mpEffect1 = MediaPlayer.create(context, R.drawable.introloop_0001);
			
			if(mpEffect2==null)
				mpEffect2 = MediaPlayer.create(context, R.drawable.ingame_loop);
		}catch(Exception e){}
	}
    public static void BgSound(Context context, int resource) {
	    if(!setValue)
		   return;
		try{
			stop(context);
			if (setValue) 
			{
				if(mpEffect0==null)
					mpEffect0 = MediaPlayer.create(context, resource);
				
				if(!mpEffect0.isPlaying())
				{
					if(resource!=2131099648)
						mpEffect0.setLooping(true);
					mpEffect0.start();
				}
			}
		}catch(Exception e){}
	}
	public static void BloodSound(Context context, int resource) {
		if(!setValue){
			mpEffect1.stop();
			 return;}
		try{
			if(mpEffect1==null)
				mpEffect1 = MediaPlayer.create(context, resource);
			if(!mpEffect1.isPlaying())
				mpEffect1.start();
			else
			{}
		}catch(Exception e){}	
	}
	public static void GameSound(Context context, int resource) {
		if(!setValue){
			mpEffect2.release();
			 return;}
		try{
			if(mpEffect2==null)
				mpEffect2 = MediaPlayer.create(context, resource);
			if(!mpEffect2.isPlaying())
				mpEffect2.start();
			else
			{}
		}catch(Exception e){}	
	}
	public static void GameOverSound(Context context, int resource) {
		 if(!setValue)
			 return;
		try{
			if(mpEffect2==null)
				mpEffect2 = MediaPlayer.create(context, resource);
			if(!mpEffect2.isPlaying())
				mpEffect2.start();
			else
			{}
		}catch(Exception e){}	
	}
	public static void BgStop() 
	{
		try{
			if (mpEffect0 != null) {
				mpEffect0.setLooping(false);
				mpEffect0.stop();
				mpEffect0.release();
				mpEffect0 = null;
			}	
		}catch(Exception e){}
	}
	public static void stop(Context context) {
		try{
			
			if (mpEffect1 != null){
				mpEffect1.stop();
				mpEffect1.release();
				mpEffect1 = null;
			}
			if (mpEffect2 != null){
				mpEffect2.stop();
				mpEffect2.release();
				mpEffect2 = null;
			}
		}catch (Exception e){}
	}
}
