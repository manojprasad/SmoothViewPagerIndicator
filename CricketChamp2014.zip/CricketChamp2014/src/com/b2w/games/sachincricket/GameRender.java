package com.b2w.games.sachincricket;

import java.util.Random;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView.Renderer;

import com.b2w.games.sachincricket.view.AdsListner;

public class GameRender implements Renderer {

	public Start mStart;
	Group mGame;
	Context mContext;
	Player throw_ball;
	int cntrX=0;
	int addbld=0;
	int abcd=0;
	boolean setBatssman=false,setKeeper=false;
	boolean ballvari=true;
	int avari=0;
	Random mfRand = new Random();
	float yline,xline;
	long startTime;
	int resumeCounter = 0;
	int betsman=0;
	int bloodCntr=0;
	int speedup=0,maxpower=0,sm=0;
	Boolean	bollerside0=false;
	Boolean	bollerside1=false;
	Boolean	bollerside2=false;
	Boolean	bollerside3=false;
	Boolean	bollerside4=false;
	Boolean	bollerside5=false;
	Boolean	bollerside6=false;
	Boolean	bollerside7=false;
	
	SimplePlane mImg_ball;
	SimplePlane mTex_Logo, mTex_Splash,mImg_play;
	SimplePlane mImg_easy,mImg_medium,mImg_hard,mImg_easy1,mImg_medium1,mImg_hard1;
	SimplePlane mImg_selectIcon;
	SimplePlane mImg_blood1,mImg_blood2,mImg_blood3;
	SimplePlane mImg_selection,mImg_Xline,mImg_Yline;
	SimplePlane mImg_bowlerSide0,mImg_bowlerSide1,mImg_bowlerSide2,mImg_bowlerSide3,mImg_bowlerSide4,mImg_bowlerSide5,mImg_bowlerSide6,mImg_bowlerSide7,mImg_bowlerSide8;
	SimplePlane[] mImg_player1, mImg_player2,mImg_player22,mImg_player3,mImg_player4,mImg_player5,mImg_player6,mImg_player7,mImg_player8, mImg_ball1;
	SimplePlane mImg_umpire,mImg_sideplayer,mImg_top;
	SimplePlane[]mImg_keeper;
	SimplePlane[]   mImg_Gplay, mImg_reset;
	SimplePlane[] mImg_outBar, mImg_bat, mImg_black, mImg_green, mImg_six,  mImg_pause;
	SimplePlane   mImg_button, mImg_stumpBase, mImg_board, mImg_scoreBar, mImg_batBase, mImg_soundOn,mImg_soundOff;
	SimplePlane mImg_Bg;
	SimplePlane[] mImg_pDeth;
	SimplePlane[] mTex1, mTex2, mTex3, mTex4, mTex6, mTex_out, mTex_Font;
	SimplePlane mTex_runs, mTex_mybest, mTex_wickets;
	SimplePlane mTex_1W, mTex_5W, mTex_11W, mTex_choosematch;
	SimplePlane mTex_congratulation, mTex_newScore, mTex_oops, mImg_newScore_Base;
	SimplePlane mTex_playagain, mTex_exit, mImg_daynightbase, mImg_day, mImg_night;
	SimplePlane mTex_tryagain, mTex_whenbatting, mTex_highestscore, mTex_bestscore;
	SimplePlane mImg_score,mImg_over;
	SimplePlane[]mImg_Star;
	SimplePlane[] image;
	SimplePlane[]mImg_bowler;
	SimplePlane[]mImg_maxPower;
	SimplePlane mImg_HospitalBg,mImg_winmedium,mImg_winhard;
	SimplePlane[] mImg_Hospital;
	SimplePlane[] mText_number;
	SimplePlane mDot;
	SimplePlane mImg_playAgain,mImg_yourScore,mImg_gameover,mImage_play,mImage_pause;
	SimplePlane mImage_Speedup[],mImage_maxPower[];
	SimplePlane mText_Overleft,mText_Playerleft,mText_Score,mText_Zero;
//	={mImg_bowlerSide0,mImg_bowlerSide1,mImg_bowlerSide2,mImg_bowlerSide3,mImg_bowlerSide4,mImg_bowlerSide5,mImg_bowlerSide6,mImg_bowlerSide7,mImg_bowlerSide8};
	
	
	float ySpeed;
	int overA=9;
	int over=10;
	int overB=5;
	int player=3;
	int i, set_value; 
	int mSel=0, mMenusel=0;
	int mScore=0,mScore1=0,mScore2=0, mBestScore=0, mWickets=0, mLevel=0;
	int mHighScoreWicket1=0, mHighScoreWicket5=0, mHighScoreWicket11=0; 
	int countX1=0, countX2=0, countP1=0, countW1=0, countValue=0, countX11=0,counterd=0,counterstar=0,counterstop=0;
	int blood=0,blood1;
	private AdsListner listner;
	
	/*private Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			mStart.adView.setVisibility(msg.what);
		}
	};*/
	
	public GameRender(Context context) {
		mContext = context;
		mStart = (Start)mContext;
		init();
		mGame = new Group(this);
		
	}
	public void setListner(AdsListner v){
		this.listner =v;
		mGame.setListner(listner);
	}
	void init() {
		try {
			mTex_Logo 		= add("logo.jpg");
			mTex_Splash		= add("splash.jpg");
			
			mTex_playagain	= add("playagain.png");
			mTex_exit		= add("exit.png");
			
			mImg_easy		= add("UI/easy.png");
			mImg_medium		= add("UI/medium.png");
			mImg_hard		= add("UI/hard.png");
			
			mImage_play		= add("play.png");
			mImage_pause	= add("pouse.png");
			
			mImg_easy1		= add("UI/easy-1.png");
			mImg_medium1		= add("UI/medium-1.png");
			mImg_hard1		= add("UI/hard-1.png");
			
			mImg_score 		= add("UI/yourscore.png");
			mImg_over		= add("UI/over.png");
			
			mImg_winmedium	= add("medium.png");
			mImg_winhard	= add("hard.png");
			
			mImg_board		= add("UI/box.png");
			mImg_batBase	= add("batbase.png");
			mImg_soundOff	= add("UI/sound-off.png");
			mImg_soundOn	= add("UI/sound-on.png");
			mImg_scoreBar	= add("score-board.png");
			mImg_stumpBase	= add("stumpbase.png");
			
			mImg_daynightbase= add("daynightbase.png");
			mImg_day		= add("day.png");
			mImg_night		= add("night.png");
			
			mImg_playAgain	= add("UI/playagain.png");
			mImg_yourScore	= add("UI/yourscore.png");
			mImg_gameover	= add("UI/gameover.png");
			
			mTex_1W			= add("tex/1wicket.png");
			mTex_5W			= add("tex/5wicket.png");
			mTex_11W		= add("tex/11wicket.png");
			mTex_choosematch= add("tex/choosematch.png");
			
			mTex_tryagain	= add("tex/tryagain.png");
			mTex_whenbatting= add("tex/whenbatting.png");
			mTex_highestscore= add("tex/highestscroe.png");
			mTex_bestscore	= add("tex/bestscroe.png");
			
			mTex_congratulation = add("tex/congrats.png");
			mTex_newScore		= add("tex/newscore.png");
			mTex_oops			= add("tex/opps.png");
			mImg_newScore_Base	= add("tex/newscorebase.png");
			
			mImg_selection=add("selection/rectangle.png");
			mImg_Xline	  =add("selection/line-1.png");
			mImg_Yline	  =add("selection/line-2.png");
			
			mImg_selectIcon=add("select-icon.png");
			
			mText_Overleft 		= add("text/overs.png");
			mText_Playerleft	= add("text/players.png");
			mText_Score			= add("text/score.png");
			mText_Zero			= add("text/0.png");
			
			mImg_bowler		=new SimplePlane[22];
			mImg_bowler[0]	=add("bowler/1.png");
			mImg_bowler[1]	=add("bowler/2.png");
			mImg_bowler[2]	=add("bowler/3.png");
			mImg_bowler[3]	=add("bowler/4.png");
			mImg_bowler[4]	=add("bowler/5.png");
			mImg_bowler[5]	=add("bowler/6.png");
			mImg_bowler[6]	=add("bowler/7.png");
			mImg_bowler[7]	=add("bowler/8.png");
			mImg_bowler[8]	=add("bowler/9.png");
			mImg_bowler[9]	=add("bowler/10.png");
			mImg_bowler[10]	=add("bowler/11.png");
			mImg_bowler[11]	=add("bowler/12.png");
			mImg_bowler[12]	=add("bowler/13.png");
			mImg_bowler[13]	=add("bowler/14.png");
			mImg_bowler[14]	=add("bowler/15.png");
			mImg_bowler[15]	=add("bowler/16.png");
			mImg_bowler[16]	=add("bowler/17.png");
			mImg_bowler[17]	=add("bowler/18.png");
			mImg_bowler[18]	=add("bowler/19.png");
			mImg_bowler[19]	=add("bowler/20.png");
			mImg_bowler[20]	=add("bowler/21.png");
			mImg_bowler[21]	=add("bowler/22.png");
			
			mImg_sideplayer =add("side-player.png");
			
			mImg_keeper		=	new SimplePlane[6];
			mImg_keeper[0]		=add("keepar/1.png");
			mImg_keeper[1]		=add("keepar/2.png");
			mImg_keeper[2]		=add("keepar/3.png");
			mImg_keeper[3]		=add("keepar/4.png");
			mImg_keeper[4]		=add("keepar/5.png");
			mImg_keeper[5]		=add("keepar/6.png");
			
			mImg_blood1		 	= add("blood-1.png");
			mImg_blood2			= add("blood-2.png");
			mImg_blood3			= add("blood-3.png");
			
			mImg_HospitalBg		= add("hospital/bg.jpg");
			mImg_Hospital		= new SimplePlane[7];
			mImg_Hospital[0]	= add("hospital/1.png");
			mImg_Hospital[1]	= add("hospital/2.png");
			mImg_Hospital[2]	= add("hospital/3.png");
			mImg_Hospital[3]	= add("hospital/4.png");
			mImg_Hospital[4]	= add("hospital/5.png");
			mImg_Hospital[5]	= add("hospital/6.png");
			mImg_Hospital[6]	= add("hospital/7.png");
			
			mImg_play	= add("play-icon.png");
			
			image 		=  new SimplePlane[8];
			image[0]	=  add("chotu/1.png");
			image[1]	=  add("chotu/2.png");
			image[2]	=  add("chotu/3.png");
			image[3]	=  add("chotu/4.png");
			image[4]	=  add("chotu/5.png");
			image[5]	=  add("chotu/6.png");
			image[6]	=  add("chotu/7.png");
			image[7]	=  add("chotu/8.png");
			
			mImg_Gplay 		= new SimplePlane[2];
			mImg_Gplay[0] 	= add("Gplay.png");
			mImg_Gplay[1] 	= add("Gplaysel.png");
			
			mImg_reset 		= new SimplePlane[2];
			mImg_reset[0] 	= add("reset.png");
			mImg_reset[1] 	= add("resetsel.png");
			
			mImg_Bg 		= add("changes/background.jpg");	
			mImg_top		=add("changes/top.png");
			mImg_black 		= new SimplePlane[2];
			mImg_black[0] 	= add("black.png");
			mImg_black[1] 	= add("blacksel.png");
			
			mImg_green 		= new SimplePlane[2];
			mImg_green[0] 	= add("green.png");
			mImg_green[1] 	= add("greensel.png");
			
			mImg_outBar 	= new SimplePlane[2];
			mImg_outBar[0] = add("outbar.png");
			mImg_outBar[1] = add("outbarsel.png");
			
			mImg_bat	 	= new SimplePlane[2];
			mImg_bat[0] 	= add("bat.png");
			mImg_bat[1]		= add("batsel.png");
			
			mImg_pause		= new SimplePlane[2];
			mImg_pause[0]	= add("pause.png");
			mImg_pause[1]	= add("pausesel.png");
			
			mImg_six		= new SimplePlane[2];
			mImg_six[0]		= add("six.png");
			mImg_six[1]		= add("sixsel.png");
		
			
			mText_number	= new SimplePlane[10];
			mText_number[0]	= add("text/0.png");
			mText_number[1]	= add("numbers/1.png");
			mText_number[2]	= add("numbers/2.png");
			mText_number[3]	= add("numbers/3.png");
			mText_number[4]	= add("numbers/4.png");
			mText_number[5]	= add("numbers/5.png");
			mText_number[6]	= add("numbers/6.png");
			mText_number[7]	= add("numbers/7.png");
			mText_number[8]	= add("numbers/8.png");
			mText_number[9]	= add("numbers/9.png");
			
			mDot			= add("dot.png");
			
			mImg_button 	= add("button.png");
			mTex1		= new SimplePlane[2];
			mTex1[0]	= add("tex/1.png");
			mTex1[1]	= add("tex/1sel.png");
			mTex2		= new SimplePlane[2];
			mTex2[0]	= add("tex/2.png");
			mTex2[1]	= add("tex/2sel.png");
			mTex3		= new SimplePlane[2];
			mTex3[0]	= add("tex/3.png");
			mTex3[1]	= add("tex/3sel.png");
			mTex4		= new SimplePlane[2];
			mTex4[0]	= add("tex/4.png");
			mTex4[1]	= add("tex/4sel.png");
			mTex6		= new SimplePlane[2];
			mTex6[0]	= add("tex/6.png");
			mTex6[1]	= add("tex/6sel.png");
			
			
			
			mTex_runs	= add("tex/runs.png");
			mTex_mybest	= add("tex/mybest.png");
			mTex_wickets= add("tex/wickets.png");
			
			mImg_umpire=add("empire.png");
			
			mImg_ball=add("ball.png");
			
			mImg_blood1=add("blood-1.png");
			mImg_blood2=add("blood-2.png");
			mImg_blood3=add("blood-3.png");
			
			mTex_out	= new SimplePlane[3];
			for(i=0;i<mTex_out.length;i++)
				mTex_out[i] = add("tex/out"+i+".png");
			
//			mImage_Speedup=new SimplePlane[7];
//			Bitmap speedup = LoadImgfromAsset("UI/speed-up.png");
//			for(i=0;i<mImage_Speedup.length;i++)
//				mImage_Speedup[i] = addBitmap(Bitmap.createBitmap(speedup,i*speedup.getHeight()/mImage_Speedup.length,0,speedup.getHeight()/mImage_Speedup.length,speedup.getWidth(),null,true));
		
			
			mImg_ball1 = new SimplePlane[3];
			Bitmap b = LoadImgfromAsset("balls.png");
			for(i=0;i<mImg_ball1.length;i++)
				mImg_ball1[i] = addBitmap(Bitmap.createBitmap(b,i*b.getWidth()/mImg_ball1.length,0,b.getWidth()/mImg_ball1.length,b.getHeight(),null,true));
		
			mImg_player1 = new SimplePlane[5];
			Bitmap p1 = LoadImgfromAsset("batsman/0.png");
			for(i=0;i<mImg_player1.length;i++)
				mImg_player1[i] = addBitmap(Bitmap.createBitmap(p1,i*p1.getWidth()/mImg_player1.length,0,p1.getWidth()/mImg_player1.length,p1.getHeight(),null,true));
			
			mImg_player2 = new SimplePlane[2];
			Bitmap p2 = LoadImgfromAsset("batsman-2.png");
			for(i=0;i<mImg_player2.length;i++)
				mImg_player2[i] = addBitmap(Bitmap.createBitmap(p2,i*p2.getWidth()/mImg_player2.length,0,p2.getWidth()/mImg_player2.length,p2.getHeight(),null,true));
			
			mImg_player22 = new SimplePlane[7];
			Bitmap p22 = LoadImgfromAsset("batsman/1.png");
			for(i=0;i<mImg_player22.length;i++)
				mImg_player22[i] = addBitmap(Bitmap.createBitmap(p22,i*p22.getWidth()/mImg_player22.length,0,p22.getWidth()/mImg_player22.length,p22.getHeight(),null,true));
			
			
			mImg_player3 = new SimplePlane[7];
			Bitmap p3 = LoadImgfromAsset("batsman/2.png");
			for(i=0;i<mImg_player3.length;i++)
				mImg_player3[i] = addBitmap(Bitmap.createBitmap(p3,i*p3.getWidth()/mImg_player3.length,0,p3.getWidth()/mImg_player3.length,p3.getHeight(),null,true));
			
			mImg_player4 = new SimplePlane[7];
			Bitmap p4 = LoadImgfromAsset("batsman/3.png");
			for(i=0;i<mImg_player4.length;i++)
				mImg_player4[i] = addBitmap(Bitmap.createBitmap(p4,i*p4.getWidth()/mImg_player4.length,0,p4.getWidth()/mImg_player4.length,p4.getHeight(),null,true));
			
			mImg_player5 = new SimplePlane[6];
			Bitmap p5 = LoadImgfromAsset("batsman/4.png");
			for(i=0;i<mImg_player5.length;i++)
				mImg_player5[i] = addBitmap(Bitmap.createBitmap(p5,i*p5.getWidth()/mImg_player5.length,0,p5.getWidth()/mImg_player5.length,p5.getHeight(),null,true));
			
			mImg_player6 = new SimplePlane[6];
			Bitmap p6 = LoadImgfromAsset("batsman/5.png");
			for(i=0;i<mImg_player6.length;i++)
				mImg_player6[i] = addBitmap(Bitmap.createBitmap(p6,i*p6.getWidth()/mImg_player6.length,0,p6.getWidth()/mImg_player6.length,p6.getHeight(),null,true));
			
			mImg_player7 = new SimplePlane[8];
			Bitmap p7 = LoadImgfromAsset("batsman/6.png");
			for(i=0;i<mImg_player7.length;i++)
				mImg_player7[i] = addBitmap(Bitmap.createBitmap(p7,i*p7.getWidth()/mImg_player7.length,0,p7.getWidth()/mImg_player7.length,p7.getHeight(),null,true));
			
			mImg_player8 = new SimplePlane[6];
			Bitmap p8 = LoadImgfromAsset("batsman/7.png");
			for(i=0;i<mImg_player8.length;i++)
				mImg_player8[i] = addBitmap(Bitmap.createBitmap(p8,i*p8.getWidth()/mImg_player8.length,0,p8.getWidth()/mImg_player8.length,p8.getHeight(),null,true));
			
			mImg_pDeth = new SimplePlane[5];
			Bitmap deth = LoadImgfromAsset("dath.png");
			for(i=0;i<mImg_pDeth.length;i++)
				mImg_pDeth[i]=addBitmap(Bitmap.createBitmap(deth,i*deth.getWidth()/mImg_pDeth.length,0,deth.getWidth()/mImg_pDeth.length,deth.getHeight(),null,true));
			
			mImg_Star = new SimplePlane[3];
			Bitmap star = LoadImgfromAsset("star-animation.png");
			for(i=0;i<mImg_Star.length;i++)
				mImg_Star[i]=addBitmap(Bitmap.createBitmap(star,i*star.getWidth()/mImg_Star.length,0,star.getWidth()/mImg_Star.length,star.getHeight(),null,true));
			
			mImage_Speedup = new SimplePlane[7];
			Bitmap speedup = LoadImgfromAsset("UI/speed-up.png");
			for(i=0;i<mImage_Speedup.length;i++)
				mImage_Speedup[i]=addBitmap(Bitmap.createBitmap(speedup,0,i*speedup.getHeight()/mImage_Speedup.length,speedup.getWidth(),speedup.getHeight()/mImage_Speedup.length,null,true));
			
			mImage_maxPower = new SimplePlane[7];
			Bitmap maxpower = LoadImgfromAsset("UI/max-power.png");
			for(i=0;i<mImage_maxPower.length;i++)
				mImage_maxPower[i]=addBitmap(Bitmap.createBitmap(maxpower,0,i*maxpower.getHeight()/mImage_maxPower.length,maxpower.getWidth(),maxpower.getHeight()/mImage_maxPower.length,null,true));
			
		
//			mImg_stump = new SimplePlane;
//			Bitmap s = LoadImgfromAsset("empire.png");
//			for(i=0;i<mImg_stump.length;i++)
//				mImg_stump[i] = addBitmap(Bitmap.createBitmap(s,i*s.getWidth()/mImg_stump.length,0,s.getWidth()/mImg_stump.length,s.getHeight(),null,true));
//			
 		    throw_ball 	= new Player();
 		    	    
			font();
			GameReset();
		
			M.GameScreen = M.GameLogo;
//			M.GameScreen = M.GameOver;
		}
		catch(Exception e){
		}
	}
	void font() {
		mTex_Font 	= new SimplePlane[10];
		Bitmap b 	= LoadImgfromAsset("tex/fontstrip.png");
		for (i=0; i<mTex_Font.length; i++)
			mTex_Font[i] = addBitmap(Bitmap.createBitmap(b, i * b.getWidth()
					/ mTex_Font.length, 0, b.getWidth() / mTex_Font.length,
					b.getHeight(), null, true));
	}
	
	void drawNumber(GL10 gl, int no, float x, float y) {
		float dx = mTex_Font[0].width();
		String strs = "" + no;
		for (int i = 0; i < strs.length(); i++) {
			int k = ((int) strs.charAt(i)) - 48;
			if (k >= 0 && k < mTex_Font.length)
			mTex_Font[k].drawPos(gl, x + i * dx, y);
		}
	}
	void GameReset() {
		
		mLevel = 0;
		mScore = 0;
		player =3;
		mScore1=0;
		mScore2=0;
		overA=9;
		over=10;
		overB=6;
		mWickets = 0;
		xline=throw_ball.x =  0.25f;
		yline=throw_ball.y =  0.45f;
		blood=0;
		blood1=0;
		throw_ball.set_ball(0.25f, 0.3f, 0, 0);
		cntrX=0;
		addbld=0;
		counterstop=0;
		counterd=0;
		maxpower=0;
		speedup=0;
		betsman=0;
		counterstar=0;
		ballvari=true;
		setBatssman=false;
		setKeeper=false;
		addbld=0;
		if(listner!=null)
			listner.showAds();
	}
	
	
	public void onDrawFrame(GL10 gl) {
		gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
		gl.glLoadIdentity();
		mGame.Draw(gl);
		
			/*if(mStart.adView!=null) {
				if(resumeCounter>150) {
					int inv=mStart.adView.getVisibility();
					if(inv==AdView.INVISIBLE){
						try{handler.sendEmptyMessage(AdView.VISIBLE);
						}catch(Exception e) {}
					}
					resumeCounter++;
					}else {
					int inv=mStart.adView.getVisibility();
					if(inv==AdView.VISIBLE){
						try{handler.sendEmptyMessage(AdView.INVISIBLE);
						}catch(Exception e){}
					}
				}
			}*/
		resumeCounter++;
	}
	public void onSurfaceChanged(GL10 gl, int width, int height) {		
		gl.glViewport(0, 0, width, height);
		gl.glMatrixMode(GL10.GL_PROJECTION);
		gl.glLoadIdentity();
		gl.glMatrixMode(GL10.GL_MODELVIEW);
		gl.glLoadIdentity();
		
	}
	public void onSurfaceCreated(GL10 gl, EGLConfig arg1) {
		
		gl.glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
		gl.glShadeModel(GL10.GL_SMOOTH);
		gl.glClearDepthf(1.0f);
		gl.glEnable(GL10.GL_DEPTH_TEST);
		gl.glDepthFunc(GL10.GL_LEQUAL);
		gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, GL10.GL_NICEST);
	}	
	SimplePlane add(String ID) {
		SimplePlane SP = null;
		Bitmap b = LoadImgfromAsset(ID);
		try {
			SP = new SimplePlane((b.getWidth()/M.mMaxX),(b.getHeight()/M.mMaxY));
			SP.loadBitmap(b);// R.drawable.snaps
		}catch(Exception e){}
		return SP;
	}
	Bitmap LoadImgfromAsset(String ID) {
		try{
			return BitmapFactory.decodeStream(mContext.getAssets().open(ID));}
		catch(Exception e) {
			return null;
		}
	}
	SimplePlane addBitmap(Bitmap b) {
		SimplePlane image = null;
		
		try {
			image = new SimplePlane((b.getWidth()/M.mMaxX),(b.getHeight()/M.mMaxY));
			image.loadBitmap(b);
			
		}catch(Exception e){}
		return image;
	}
	SimplePlane addBitmap1(Bitmap b) {
		SimplePlane image = null;
		
		try {
			image = new SimplePlane((b.getHeight()/M.mMaxY),(b.getWidth()/M.mMaxX));
			image.loadBitmap(b);
			
		}catch(Exception e){}
		return image;
	}
}
